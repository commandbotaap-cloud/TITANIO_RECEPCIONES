package com.almacen.recepcion;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.*;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.*;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "AlmacenUSB";
    private static final String ACTION_USB_PERMISSION = "com.almacen.recepcion.USB_PERMISSION";

    private WebView webView;
    private UsbManager usbManager;
    private UsbDevice barcodeDevice;
    private UsbDeviceConnection connection;
    private UsbEndpoint endpointIn;
    private Thread readThread;
    private volatile boolean isReading = false;

    // Barcode buffer for keyboard-mode scanners
    private StringBuilder keyBuffer = new StringBuilder();
    private long lastKeyTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }

        // Setup WebView
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setDatabaseEnabled(true);

        // JavaScript bridge for USB scanner
        webView.addJavascriptInterface(new WebBridge(), "AndroidBridge");

        // WebView client
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                // Allow WhatsApp links to open externally
                if (url.startsWith("https://wa.me") || url.startsWith("whatsapp://")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, request.getUrl());
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });

        // WebChrome client for file upload (camera, gallery)
        webView.setWebChromeClient(new WebChromeClient() {
            private ValueCallback<android.net.Uri[]> uploadCallback;

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<android.net.Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, 1001);
                } catch (Exception e) {
                    uploadCallback = null;
                    return false;
                }
                return true;
            }
        });

        // Load the app HTML
        webView.loadUrl("file:///android_asset/index.html");

        // USB Setup
        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        registerUsbReceiver();
        checkConnectedDevices();
    }

    // ═══ KEYBOARD EVENT CAPTURE ═══
    // This captures barcode scanners that Android DOES recognize as keyboard
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            long now = System.currentTimeMillis();
            int keyCode = event.getKeyCode();

            // Enter key = barcode complete
            if (keyCode == KeyEvent.KEYCODE_ENTER) {
                if (keyBuffer.length() >= 3 && (now - lastKeyTime) < 200) {
                    String barcode = keyBuffer.toString().trim();
                    keyBuffer.setLength(0);
                    sendBarcodeToWeb(barcode);
                    return true;
                }
                keyBuffer.setLength(0);
                return super.dispatchKeyEvent(event);
            }

            // Regular character
            char c = (char) event.getUnicodeChar();
            if (c > 0 && !Character.isISOControl(c)) {
                // If too much time passed, reset buffer (not a barcode gun)
                if (keyBuffer.length() > 0 && (now - lastKeyTime) > 200) {
                    keyBuffer.setLength(0);
                }
                keyBuffer.append(c);
                lastKeyTime = now;

                // If typing fast (barcode gun), consume the event
                if (keyBuffer.length() > 1 && (now - lastKeyTime) < 100) {
                    return true; // Don't pass to WebView
                }
            }
        }
        return super.dispatchKeyEvent(event);
    }

    // ═══ USB HOST - DIRECT COMMUNICATION ═══
    // This handles scanners that Android does NOT recognize as keyboard

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                synchronized (this) {
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        if (device != null) {
                            connectToDevice(device);
                        }
                    } else {
                        Log.d(TAG, "USB permission denied");
                        runOnUiThread(() -> Toast.makeText(context, "Permiso USB denegado", Toast.LENGTH_SHORT).show());
                    }
                }
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {
                UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (device != null) {
                    Log.d(TAG, "USB device attached: " + device.getDeviceName());
                    runOnUiThread(() -> Toast.makeText(context, "Dispositivo USB detectado: " + device.getProductName(), Toast.LENGTH_SHORT).show());
                    requestPermission(device);
                }
            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
                UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (device != null && device.equals(barcodeDevice)) {
                    disconnectDevice();
                    runOnUiThread(() -> Toast.makeText(context, "Pistola desconectada", Toast.LENGTH_SHORT).show());
                    sendStatusToWeb(false);
                }
            }
        }
    };

    private void registerUsbReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_USB_PERMISSION);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(usbReceiver, filter);
        }
    }

    private void checkConnectedDevices() {
        HashMap<String, UsbDevice> deviceList = usbManager.getDeviceList();
        for (UsbDevice device : deviceList.values()) {
            Log.d(TAG, "Found USB device: " + device.getProductName() + " VID:" + device.getVendorId() + " PID:" + device.getProductId());
            requestPermission(device);
        }
    }

    private void requestPermission(UsbDevice device) {
        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? PendingIntent.FLAG_MUTABLE : 0;
        PendingIntent permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), flags);
        usbManager.requestPermission(device, permissionIntent);
    }

    private void connectToDevice(UsbDevice device) {
        barcodeDevice = device;
        Log.d(TAG, "Connecting to: " + device.getProductName() + " Interfaces: " + device.getInterfaceCount());

        // Try to find an input endpoint (HID or bulk)
        for (int i = 0; i < device.getInterfaceCount(); i++) {
            UsbInterface iface = device.getInterface(i);
            Log.d(TAG, "Interface " + i + " class:" + iface.getInterfaceClass() + " endpoints:" + iface.getEndpointCount());

            for (int j = 0; j < iface.getEndpointCount(); j++) {
                UsbEndpoint ep = iface.getEndpoint(j);
                if (ep.getDirection() == UsbConstants.USB_DIR_IN) {
                    // Found input endpoint
                    connection = usbManager.openDevice(device);
                    if (connection != null) {
                        connection.claimInterface(iface, true);
                        endpointIn = ep;
                        startReading();
                        runOnUiThread(() -> {
                            Toast.makeText(this, "✅ Pistola conectada", Toast.LENGTH_SHORT).show();
                            sendStatusToWeb(true);
                        });
                        return;
                    }
                }
            }
        }
        Log.d(TAG, "No input endpoint found");
        runOnUiThread(() -> Toast.makeText(this, "No se encontro endpoint de entrada", Toast.LENGTH_SHORT).show());
    }

    private void startReading() {
        isReading = true;
        readThread = new Thread(() -> {
            byte[] buffer = new byte[64];
            StringBuilder barcodeBuffer = new StringBuilder();

            while (isReading && connection != null) {
                int bytesRead = connection.bulkTransfer(endpointIn, buffer, buffer.length, 100);
                if (bytesRead > 0) {
                    // Parse HID keyboard report or raw data
                    String data = parseHIDReport(buffer, bytesRead);
                    if (data != null) {
                        if (data.equals("\n") || data.equals("\r")) {
                            // Enter = barcode complete
                            if (barcodeBuffer.length() >= 1) {
                                final String barcode = barcodeBuffer.toString().trim();
                                barcodeBuffer.setLength(0);
                                runOnUiThread(() -> sendBarcodeToWeb(barcode));
                            }
                        } else {
                            barcodeBuffer.append(data);
                        }
                    }
                }
            }
        });
        readThread.setDaemon(true);
        readThread.start();
    }

    // Parse USB HID keyboard report to characters
    private String parseHIDReport(byte[] data, int length) {
        if (length < 3) return null;

        // Standard HID keyboard report: [modifier, reserved, key1, key2, ...]
        // Key codes: https://usb.org/sites/default/files/hut1_2.pdf (page 53)
        byte keyCode = data[2];
        if (keyCode == 0) return null; // No key pressed

        boolean shift = (data[0] & 0x22) != 0; // Left or right shift

        // Enter
        if (keyCode == 0x28 || keyCode == 0x58) return "\n";

        // Numbers 1-9, 0
        if (keyCode >= 0x1E && keyCode <= 0x26) return String.valueOf((char)('1' + (keyCode - 0x1E)));
        if (keyCode == 0x27) return "0";

        // Letters a-z
        if (keyCode >= 0x04 && keyCode <= 0x1D) {
            char c = (char)('a' + (keyCode - 0x04));
            return shift ? String.valueOf(Character.toUpperCase(c)) : String.valueOf(c);
        }

        // Special chars
        if (keyCode == 0x2D) return shift ? "_" : "-";
        if (keyCode == 0x2E) return shift ? "+" : "=";
        if (keyCode == 0x2F) return shift ? "{" : "[";
        if (keyCode == 0x30) return shift ? "}" : "]";
        if (keyCode == 0x33) return shift ? ":" : ";";
        if (keyCode == 0x34) return shift ? "\"" : "'";
        if (keyCode == 0x36) return shift ? "<" : ",";
        if (keyCode == 0x37) return shift ? ">" : ".";
        if (keyCode == 0x38) return shift ? "?" : "/";
        if (keyCode == 0x2C) return " "; // Space

        // Try raw ASCII for anything else
        if (length > 2) {
            for (int i = 2; i < length; i++) {
                if (data[i] >= 32 && data[i] < 127) {
                    return String.valueOf((char) data[i]);
                }
            }
        }

        return null;
    }

    private void disconnectDevice() {
        isReading = false;
        if (connection != null) {
            connection.close();
            connection = null;
        }
        endpointIn = null;
        barcodeDevice = null;
    }

    // ═══ JAVASCRIPT BRIDGE ═══

    private void sendBarcodeToWeb(String barcode) {
        Log.d(TAG, "Barcode scanned: " + barcode);
        // Vibrate
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null) v.vibrate(150);

        // Send to WebView
        String js = "javascript:window.dispatchEvent(new CustomEvent('usb-barcode',{detail:{code:'" + barcode.replace("'", "\\'") + "'}}));";
        webView.evaluateJavascript(js, null);
    }

    private void sendStatusToWeb(boolean connected) {
        String js = "javascript:window.dispatchEvent(new CustomEvent('usb-scanner-status',{detail:{connected:" + connected + "}}));";
        webView.evaluateJavascript(js, null);
    }

    // Bridge methods callable from JavaScript
    public class WebBridge {
        @JavascriptInterface
        public boolean isScannerConnected() {
            return barcodeDevice != null && connection != null;
        }

        @JavascriptInterface
        public String getScannerName() {
            if (barcodeDevice != null) {
                return barcodeDevice.getProductName();
            }
            return "No conectada";
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.vibrate(ms);
        }

        @JavascriptInterface
        public void showToast(String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        disconnectDevice();
        try { unregisterReceiver(usbReceiver); } catch (Exception ignored) {}
    }
}
