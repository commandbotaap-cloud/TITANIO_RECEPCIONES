import { useState, useEffect, useRef, useCallback } from "react";

/* ─── STORAGE ──────────────────────────────────────────── */
const KEY_INDEX = "alm-recepciones-index-v2";
const keyRec = (id) => `alm-rec-${id}-v2`;

/* ─── HELPERS ──────────────────────────────────────────── */
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const fmt = (ts) => ts ? new Date(ts).toLocaleDateString("es-VE", { day: "2-digit", month: "short", year: "2-digit" }) : "—";

/* ─── IMAGE COMPRESSION ───────────────────────────────── */
function compressImage(file, maxWidth = 1600, quality = 0.82) {
  return new Promise((resolve, reject) => {
    // If file is small enough already (<800KB), skip compression
    if (file.size < 800_000) {
      const r = new FileReader();
      r.onload = () => resolve({ base64: r.result.split(",")[1], mediaType: file.type || "image/jpeg" });
      r.onerror = () => reject(new Error("No se pudo leer el archivo"));
      r.readAsDataURL(file);
      return;
    }
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      let w = img.width, h = img.height;
      if (w > maxWidth) { h = Math.round(h * (maxWidth / w)); w = maxWidth; }
      const canvas = document.createElement("canvas");
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, w, h);
      const dataUrl = canvas.toDataURL("image/jpeg", quality);
      const base64 = dataUrl.split(",")[1];
      if (!base64 || base64.length < 100) { reject(new Error("Compresión falló: imagen vacía")); return; }
      resolve({ base64, mediaType: "image/jpeg" });
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Imagen corrupta o formato no soportado")); };
    img.src = url;
  });
}

const fileToPreview = (file) => new Promise((res) => {
  const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(file);
});

/* ─── API ──────────────────────────────────────────────── */
const API_HEADERS = {
  "Content-Type": "application/json",
  "anthropic-version": "2023-06-01",
  "anthropic-dangerous-direct-browser-access": "true",
};

/* ─── MODELOS ──────────────────────────────────────────── */
const MODELO_PRECISO = "claude-opus-4-6";
const MODELO_RAPIDO = "claude-sonnet-4-20250514";

function parseJSON(text) {
  const clean = text.replace(/```json|```/g, "").trim();
  const start = clean.indexOf("{");
  const end = clean.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) {
    // Try array
    const aStart = clean.indexOf("[");
    const aEnd = clean.lastIndexOf("]");
    if (aStart !== -1 && aEnd > aStart) return JSON.parse(clean.slice(aStart, aEnd + 1));
    throw new Error("No se encontró JSON válido en la respuesta");
  }
  return JSON.parse(clean.slice(start, end + 1));
}

async function callAPI(messages, system, maxTokens = 4000, model = MODELO_PRECISO) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 120_000);
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: API_HEADERS,
      signal: controller.signal,
      body: JSON.stringify({ model, max_tokens: maxTokens, system, messages }),
    });
    clearTimeout(timeout);
    if (res.status === 401) throw new Error("401 — API key inválida o expirada");
    if (res.status === 429) throw new Error("429 — Demasiadas solicitudes, espera 30 segundos");
    if (res.status >= 500) throw new Error(`${res.status} — Error del servidor de Claude`);
    if (!res.ok) throw new Error(`Error HTTP ${res.status}`);
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    return data.content?.find(b => b.type === "text")?.text || "";
  } catch (err) {
    clearTimeout(timeout);
    if (err.name === "AbortError") throw new Error("408 — Timeout: la imagen tardó más de 2 minutos");
    throw err;
  }
}

/* ─── EXTRACCIÓN 3-PASOS ──────────────────────────────── */
async function extraerFactura(base64, mediaType, onStep) {
  const imgBlock = { type: "image", source: { type: "base64", media_type: mediaType, data: base64 } };

  // ══ PASO 1: Extracción completa ══
  onStep?.("Extrayendo productos...");
  const paso1 = await callAPI(
    [{ role: "user", content: [
      imgBlock,
      { type: "text", text: `Analiza esta factura/nota de entrega y extrae CADA línea de producto visible.

INSTRUCCIONES CRÍTICAS:
1. Lee TODOS los productos, no dejes ninguno fuera
2. Para cada producto identifica: número de ítem, código/referencia/SKU, nombre/descripción, unidad de medida, cantidad
3. Los códigos de referencia son EXACTOS — deletrea cada carácter
4. Si ves códigos alfanuméricos con guiones (ej: GV-CH60200-TH), cópialos EXACTAMENTE
5. Distingue con cuidado: G≠C, 0≠O, 1≠I≠l, 5≠S, 8≠B, 2≠Z, D≠O, V≠U, H≠N

Responde SOLO con JSON válido, sin markdown ni explicaciones:
{"proveedor":"nombre del proveedor","nro_factura":"número de factura","items":[{"item":"01","referencia":"CODIGO-EXACTO","nombre":"descripción del producto","unidad":"und","qty_factura":10}]}

Si un campo no es visible usa "—" para texto o 0 para números.` }
    ]}],
    `Eres un sistema de extracción de facturas industriales venezolanas con precisión forense. Tu trabajo es leer CADA producto visible en la imagen. Nunca omitas líneas. Los códigos de referencia deben ser EXACTOS carácter por carácter. Responde SOLO con JSON válido.`,
    4000
  );

  const resultado = parseJSON(paso1);
  if (!resultado.items || !Array.isArray(resultado.items) || resultado.items.length === 0) {
    throw new Error("Sin productos detectados — la imagen puede estar borrosa o no contiene una factura legible");
  }

  // ══ PASO 2: Verificación ciega de códigos ══
  onStep?.("Verificando códigos...");
  const nItems = resultado.items.length;

  const paso2 = await callAPI(
    [{ role: "user", content: [
      imgBlock,
      { type: "text", text: `Esta factura tiene ${nItems} líneas de productos.

TAREA: Para CADA línea de producto (de arriba a abajo), localiza su código de referencia/SKU en la imagen y DELETRÉALO carácter por carácter.

MÉTODO OBLIGATORIO para cada código:
1. Ubica visualmente el código en la línea
2. Lee CADA carácter de izquierda a derecha
3. Confirma visualmente cada carácter antes de avanzar al siguiente
4. Arma el código completo

REGLAS DE LECTURA VISUAL (sin excepción):
• G tiene barra horizontal interna → DISTINTA de C (curva abierta)
• 0 (cero) es ovalado → DISTINTO de O (letra, más redonda)  
• 1 tiene remate superior → DISTINTO de I (con serifs) y l (ele minúscula)
• Guiones (-), puntos (.), barras (/) son parte del código
• Mayúsculas y minúsculas importan
• 2≠Z, 5≠S, 6≠b, 8≠B, V≠U, H≠N≠M, D≠O, Q≠O

También verifica la CANTIDAD de cada línea leyendo el número en la columna de cantidad.

Responde SOLO con JSON sin markdown:
{"verificacion":[{"linea":1,"codigo_deletreado":"X-Y-Z","cantidad":10,"confianza":"alta|media|baja"}]}

confianza: "alta" = perfectamente legible, "media" = legible con esfuerzo, "baja" = parcialmente ilegible` }
    ]}],
    `Eres un verificador forense de códigos de productos. Tu método es deletrear CADA carácter individualmente mirando la imagen, nunca asumes ni copias de memoria. Cada código debe ser verificado visualmente carácter por carácter. Responde SOLO con JSON.`,
    4000
  );

  let verificacion = null;
  try {
    const v = parseJSON(paso2);
    if (Array.isArray(v.verificacion) && v.verificacion.length >= 1) {
      verificacion = v.verificacion;
    }
  } catch (_) { /* Si falla paso 2, seguimos con paso 1 */ }

  // ══ PASO 3: Auditoría cruzada ══
  if (verificacion && verificacion.length === nItems) {
    onStep?.("Auditoría final...");
    // Compare and detect discrepancies
    const discrepancias = [];
    resultado.items.forEach((it, i) => {
      const v = verificacion[i];
      if (v && v.codigo_deletreado) {
        const refP1 = (it.referencia || "").trim().toUpperCase();
        const refP2 = (v.codigo_deletreado || "").trim().toUpperCase();
        if (refP1 !== refP2 && refP2 !== "—" && refP2.length > 0) {
          discrepancias.push({ linea: i + 1, paso1: it.referencia, paso2: v.codigo_deletreado });
        }
      }
    });

    if (discrepancias.length > 0 && discrepancias.length <= 8) {
      // Ask Opus to arbitrate
      const listaDisc = discrepancias.map(d => 
        `Línea ${d.linea}: Lectura A="${d.paso1}" vs Lectura B="${d.paso2}"`
      ).join("\n");

      try {
        const paso3 = await callAPI(
          [{ role: "user", content: [
            imgBlock,
            { type: "text", text: `Hay discrepancias en ${discrepancias.length} códigos entre dos lecturas independientes:

${listaDisc}

Para CADA discrepancia, mira la imagen y determina cuál lectura es CORRECTA (A o B), o proporciona la lectura correcta si ambas están mal.

Responde SOLO con JSON:
{"arbitraje":[{"linea":1,"codigo_correcto":"VALOR-FINAL"}]}` }
          ]}],
          `Eres el árbitro final de lectura de códigos. Dos lecturas independientes dieron resultados distintos. Tu trabajo es mirar la imagen original y determinar el valor correcto de cada código en disputa. Sé extremadamente preciso. Responde SOLO con JSON.`,
          2000
        );
        const arb = parseJSON(paso3);
        if (Array.isArray(arb.arbitraje)) {
          arb.arbitraje.forEach(a => {
            const idx = (a.linea || 0) - 1;
            if (idx >= 0 && idx < resultado.items.length && a.codigo_correcto) {
              resultado.items[idx].referencia = a.codigo_correcto.trim();
              resultado.items[idx]._arbitrado = true;
            }
          });
        }
      } catch (_) { /* If arbitration fails, use paso2 results */ }
    }

    // Apply paso2 verifications (where no arbitration happened)
    verificacion.forEach((v, i) => {
      if (i < resultado.items.length && !resultado.items[i]._arbitrado) {
        if (v.codigo_deletreado && v.codigo_deletreado !== "—") {
          resultado.items[i].referencia = v.codigo_deletreado.trim();
        }
        if (v.cantidad && v.cantidad > 0) {
          resultado.items[i].qty_factura = v.cantidad;
        }
      }
      if (i < resultado.items.length) {
        resultado.items[i]._confianza = v?.confianza || "media";
        delete resultado.items[i]._arbitrado;
      }
    });
  } else if (verificacion) {
    // Partial verification — apply what we can
    verificacion.forEach((v, i) => {
      if (i < resultado.items.length) {
        if (v.codigo_deletreado && v.codigo_deletreado !== "—") {
          resultado.items[i].referencia = v.codigo_deletreado.trim();
        }
        if (v.cantidad && v.cantidad > 0) {
          resultado.items[i].qty_factura = v.cantidad;
        }
        resultado.items[i]._confianza = v?.confianza || "media";
      }
    });
  }

  return resultado;
}

/* ─── EXTRACCIÓN RÁPIDA (1 sola llamada, Sonnet) ──────── */
async function extraerFacturaRapido(base64, mediaType, onStep) {
  const imgBlock = { type: "image", source: { type: "base64", media_type: mediaType, data: base64 } };
  onStep?.("Leyendo factura (modo rápido)...");
  
  const resp = await callAPI(
    [{ role: "user", content: [
      imgBlock,
      { type: "text", text: `Extrae TODOS los productos de esta factura venezolana. Para cada producto lee: item, referencia/código, nombre, unidad, cantidad.

IMPORTANTE: Los códigos de referencia deben ser EXACTOS. Distingue G≠C, 0≠O, 1≠I, 5≠S, 8≠B.

Responde SOLO con JSON válido sin markdown:
{"proveedor":"","nro_factura":"","items":[{"item":"01","referencia":"CODIGO","nombre":"descripcion","unidad":"und","qty_factura":10}]}` }
    ]}],
    `Extractor de facturas industriales. Lee TODOS los productos. Códigos EXACTOS. Solo JSON.`,
    4000,
    MODELO_RAPIDO
  );
  
  const resultado = parseJSON(resp);
  if (!resultado.items?.length) throw new Error("Sin productos detectados");
  resultado.items.forEach(it => { it._confianza = "media"; });
  return resultado;
}

/* ─── ERROR DIAGNOSIS ──────────────────────────────────── */
function diagnosticarError(msg) {
  if (!msg) return { icon: "❓", titulo: "Error desconocido", causa: "No se pudo determinar la causa.", solucion: "Intenta reintentar la foto.", accion: "retry", needsNewPhoto: false };
  const m = msg.toLowerCase();

  if (m.includes("401") || m.includes("authentication") || m.includes("api key") || m.includes("unauthorized"))
    return { icon: "🔑", titulo: "Error de autenticación", causa: "La clave de API no es válida o expiró.", solucion: "Recarga la página. Si persiste, verifica tu API key.", accion: "retry", needsNewPhoto: false };

  if (m.includes("429") || m.includes("rate limit") || m.includes("too many") || m.includes("demasiadas"))
    return { icon: "⏱️", titulo: "Demasiadas solicitudes", causa: "Se enviaron demasiadas fotos seguidas y la API está en pausa.", solucion: "Espera 30 segundos y presiona Reintentar. No necesitas otra foto.", accion: "retry", needsNewPhoto: false };

  if (m.includes("500") || m.includes("502") || m.includes("503") || m.includes("504") || m.includes("servidor"))
    return { icon: "🌐", titulo: "Error del servidor", causa: "El servidor de Claude tuvo un fallo temporal.", solucion: "No es tu foto. Presiona Reintentar en unos segundos.", accion: "retry", needsNewPhoto: false };

  if (m.includes("network") || m.includes("failed to fetch") || m.includes("conexión") || m.includes("connection") || m.includes("fetch"))
    return { icon: "📡", titulo: "Sin conexión", causa: "Se perdió la conexión a internet durante el procesamiento.", solucion: "Verifica tu WiFi o datos y presiona Reintentar.", accion: "retry", needsNewPhoto: false };

  if (m.includes("corrupta") || m.includes("formato no soportado"))
    return { icon: "🖼️", titulo: "Imagen corrupta", causa: "El archivo de imagen está dañado o en un formato que no se puede leer.", solucion: "Toma una nueva foto directamente con la cámara.", accion: "new_photo", needsNewPhoto: true };

  if (m.includes("vacía") || m.includes("ilegible") || m.includes("empty") || m.includes("compresión falló"))
    return { icon: "📁", titulo: "Archivo no legible", causa: "El archivo de imagen no se pudo procesar correctamente.", solucion: "Vuelve a tomar la foto con la cámara.", accion: "new_photo", needsNewPhoto: true };

  if (m.includes("sin productos") || m.includes("no contiene") || m.includes("borrosa"))
    return { icon: "🔍", titulo: "Sin productos detectados", causa: "La IA no encontró productos en la imagen. La foto puede estar borrosa, oscura o con mal ángulo.", solucion: "Toma otra foto: más cerca, con buena luz, encuadrando toda la factura sin sombras.", accion: "new_photo", needsNewPhoto: true };

  if (m.includes("json") || m.includes("parse") || m.includes("unexpected") || m.includes("syntax") || m.includes("no se encontró json"))
    return { icon: "⚙️", titulo: "Respuesta inesperada", causa: "La IA devolvió un formato que no se pudo interpretar. Puede ser una imagen confusa.", solucion: "Presiona Reintentar. Si persiste, toma otra foto con mejor enfoque.", accion: "retry_or_photo", needsNewPhoto: false };

  if (m.includes("408") || m.includes("timeout") || m.includes("abort") || m.includes("2 minutos"))
    return { icon: "⌛", titulo: "Tiempo agotado", causa: "La imagen tardó demasiado en procesarse (puede ser muy pesada o la conexión lenta).", solucion: "Presiona Reintentar. Si vuelve a fallar, toma una foto más pequeña.", accion: "retry", needsNewPhoto: false };

  if (m.includes("overloaded") || m.includes("carga"))
    return { icon: "🔥", titulo: "Servidor sobrecargado", causa: "Claude está recibiendo muchas solicitudes en este momento.", solucion: "Espera 1 minuto y presiona Reintentar.", accion: "retry", needsNewPhoto: false };

  return { icon: "⚠️", titulo: "Error al procesar", causa: msg, solucion: "Presiona Reintentar. Si persiste, toma otra foto con mejor iluminación.", accion: "retry_or_photo", needsNewPhoto: false };
}

/* ─── STATUS HELPERS ───────────────────────────────────── */
const statusColor = (qf, qc) => {
  if (qc === 0 && qf > 0) return C.red;
  if (qc === qf && qf > 0) return C.green;
  if (qc < qf) return C.amber;
  return C.blue;
};
const statusLabel = (qf, qc) => {
  if (qc === 0 && qf > 0) return "Pendiente";
  if (qc === qf && qf > 0) return "Conforme";
  if (qc < qf) return `Faltan ${qf - qc}`;
  return `Exceso +${qc - qf}`;
};

/* ─── DESIGN TOKENS ────────────────────────────────────── */
const C = {
  orange: "#FF6B00",
  orangeLight: "#FF8C38",
  orangePale: "#FFF3EB",
  orangeMid: "#FFE0C8",
  white: "#FFFFFF",
  bg: "#F2F2F7",
  card: "#FFFFFF",
  text: "#1C1C1E",
  textSecondary: "#6C6C70",
  textTertiary: "#AEAEB2",
  separator: "#E5E5EA",
  green: "#34C759",
  greenPale: "#E8F8ED",
  red: "#FF3B30",
  redPale: "#FFEBEA",
  amber: "#FF9500",
  amberPale: "#FFF4E0",
  blue: "#007AFF",
  bluePale: "#EBF4FF",
};

const SF = "'SF Pro Display', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', sans-serif";

/* ══════════════════════════════════════════════════════════
   APP ROOT
══════════════════════════════════════════════════════════ */
export default function App() {
  const [view, setView] = useState("home");
  const [recepcionId, setRecepcionId] = useState(null);
  const [index, setIndex] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try { const r = await window.storage.get(KEY_INDEX); if (r?.value) setIndex(JSON.parse(r.value)); } catch (_) {}
      setLoading(false);
    })();
  }, []);

  const saveIndex = async (ni) => { setIndex(ni); await window.storage.set(KEY_INDEX, JSON.stringify(ni)); };

  const crearRecepcion = async () => {
    const id = uid();
    const nombre = `Recepción #${String(index.length + 1).padStart(3, "0")}`;
    const rec = { id, nombre, fecha: Date.now(), proveedor: "", nro_factura: "", estado: "abierta", items: [], facturas_procesadas: 0 };
    await window.storage.set(keyRec(id), JSON.stringify(rec));
    await saveIndex([{ id, nombre, fecha: rec.fecha, nItems: 0, estado: "abierta", proveedor: "" }, ...index]);
    setRecepcionId(id); setView("recepcion");
  };

  const eliminarRecepcion = async (id) => {
    if (!confirm("¿Eliminar esta recepción?")) return;
    try { await window.storage.delete(keyRec(id)); } catch (_) {}
    await saveIndex(index.filter((r) => r.id !== id));
  };

  const eliminarTodas = async () => {
    if (!confirm("¿Eliminar TODAS las recepciones? Esta acción no se puede deshacer.")) return;
    for (const r of index) { try { await window.storage.delete(keyRec(r.id)); } catch (_) {} }
    await saveIndex([]);
  };

  if (loading) return <Loader />;
  if (view === "recepcion" && recepcionId)
    return <RecepcionView id={recepcionId} onBack={() => setView("home")}
      onUpdate={(patch) => saveIndex(index.map((r) => r.id === recepcionId ? { ...r, ...patch } : r))} />;
  return <HomeView index={index} onCrear={crearRecepcion}
    onAbrir={(id) => { setRecepcionId(id); setView("recepcion"); }}
    onEliminar={eliminarRecepcion}
    onEliminarTodas={eliminarTodas} />;
}

/* ══════════════════════════════════════════════════════════
   HOME
══════════════════════════════════════════════════════════ */
function HomeView({ index, onCrear, onAbrir, onEliminar, onEliminarTodas }) {
  const abiertas = index.filter((r) => r.estado === "abierta");
  const cerradas = index.filter((r) => r.estado === "cerrada");
  return (
    <div style={{ background: C.bg, minHeight: "100vh", fontFamily: SF }}>
      <div style={{ background: "rgba(255,255,255,0.85)", backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)", borderBottom: `1px solid ${C.separator}`, padding: "16px 20px 14px", position: "sticky", top: 0, zIndex: 50 }}>
        <div style={{ maxWidth: 640, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontSize: 12, color: C.orange, fontWeight: 600, letterSpacing: 0.5, marginBottom: 1 }}>ALMACÉN · RECEPCIÓN</div>
            <div style={{ fontSize: 26, fontWeight: 700, color: C.text, letterSpacing: -0.5 }}>Recepciones</div>
          </div>
          <button onClick={onCrear} style={{ background: C.orange, border: "none", borderRadius: 22, padding: "10px 20px", color: "#fff", fontFamily: SF, fontSize: 15, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 6, boxShadow: `0 4px 14px ${C.orange}55` }}>
            <span style={{ fontSize: 18, lineHeight: 1 }}>+</span> Nueva
          </button>
        </div>
      </div>

      <div style={{ padding: "20px 16px 100px", maxWidth: 640, margin: "0 auto" }}>
        {index.length === 0 && (
          <div style={{ textAlign: "center", padding: "80px 0" }}>
            <div style={{ width: 80, height: 80, background: C.orangePale, borderRadius: 24, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 38, margin: "0 auto 16px" }}>📋</div>
            <div style={{ fontSize: 20, fontWeight: 600, color: C.text, marginBottom: 6 }}>Sin recepciones</div>
            <div style={{ fontSize: 15, color: C.textSecondary }}>Crea una nueva para empezar a escanear facturas</div>
          </div>
        )}

        {abiertas.length > 0 && (
          <div style={{ marginBottom: 28 }}>
            <div style={sectionTitle}>En proceso</div>
            <div style={cardGroup}>
              {abiertas.map((r, i) => <FolderCard key={r.id} r={r} onAbrir={onAbrir} onEliminar={onEliminar} last={i === abiertas.length - 1} />)}
            </div>
          </div>
        )}
        {cerradas.length > 0 && (
          <div>
            <div style={sectionTitle}>Cerradas</div>
            <div style={cardGroup}>
              {cerradas.map((r, i) => <FolderCard key={r.id} r={r} onAbrir={onAbrir} onEliminar={onEliminar} closed last={i === cerradas.length - 1} />)}
            </div>
          </div>
        )}
        {index.length > 0 && (
          <button onClick={onEliminarTodas} style={{ width: "100%", marginTop: 30, background: "none", border: `1px solid ${C.red}30`, borderRadius: 12, padding: "12px", color: C.red, fontFamily: SF, fontSize: 13, fontWeight: 500, cursor: "pointer", opacity: 0.6 }}>
            Borrar todas las recepciones
          </button>
        )}
      </div>
    </div>
  );
}

const sectionTitle = { fontSize: 13, fontWeight: 600, color: C.textSecondary, letterSpacing: 0.3, marginBottom: 8, paddingLeft: 4, textTransform: "uppercase" };
const cardGroup = { background: C.card, borderRadius: 16, overflow: "hidden", boxShadow: "0 1px 3px rgba(0,0,0,0.06)" };

function FolderCard({ r, onAbrir, onEliminar, closed, last }) {
  return (
    <div onClick={() => onAbrir(r.id)} style={{ padding: "14px 16px", display: "flex", alignItems: "center", gap: 14, cursor: "pointer", borderBottom: last ? "none" : `1px solid ${C.separator}`, background: C.white }}>
      <div style={{ width: 44, height: 44, borderRadius: 12, background: closed ? "#F2F2F7" : C.orangePale, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>
        {closed ? "📁" : "📂"}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 16, fontWeight: 600, color: closed ? C.textSecondary : C.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{r.nombre}</div>
        {r.proveedor && <div style={{ fontSize: 13, color: C.orange, marginTop: 1 }}>{r.proveedor}</div>}
        <div style={{ fontSize: 12, color: C.textTertiary, marginTop: 2 }}>{fmt(r.fecha)} · {r.nItems || 0} productos</div>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ fontSize: 12, fontWeight: 600, padding: "4px 10px", borderRadius: 20, background: closed ? "#F2F2F7" : C.orangePale, color: closed ? C.textTertiary : C.orange }}>{closed ? "Cerrada" : "Activa"}</div>
        <button onClick={(e) => { e.stopPropagation(); onEliminar(r.id); }} style={{ background: "none", border: "none", color: C.textTertiary, fontSize: 18, cursor: "pointer", padding: 4, lineHeight: 1 }}>×</button>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   RECEPCIÓN DETAIL
══════════════════════════════════════════════════════════ */
function RecepcionView({ id, onBack, onUpdate }) {
  const [rec, setRec] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeItem, setActiveItem] = useState(null);
  const [tab, setTab] = useState("items");
  const [showQueue, setShowQueue] = useState(false);
  const [showPaste, setShowPaste] = useState(false);
  const [scanMode, setScanMode] = useState("rapido");
  const [queue, setQueue] = useState([]);
  const [gunBuffer, setGunBuffer] = useState("");
  const [gunToast, setGunToast] = useState(null); // {code, matched, itemName}
  const fileMapRef = useRef({});
  const processingRef = useRef(false);
  const recRef = useRef(null);
  const queueRef = useRef([]);
  const cameraRef = useRef();
  const galleryRef = useRef();
  const scanModeRef = useRef("rapido");
  const gunBufferRef = useRef("");
  const gunTimerRef = useRef(null);

  // Keep refs in sync
  useEffect(() => { queueRef.current = queue; }, [queue]);
  useEffect(() => { scanModeRef.current = scanMode; }, [scanMode]);

  /* ── GLOBAL BARCODE GUN LISTENER ──
     Barcode guns type characters very fast (<50ms between keys) then send Enter.
     We detect this pattern: if chars arrive <80ms apart and end with Enter,
     it's a barcode gun. Otherwise it's normal typing.
  ── */
  useEffect(() => {
    let buffer = "";
    let timer = null;

    const handleKeyDown = (e) => {
      // Ignore if user is focused on an input/textarea
      const tag = document.activeElement?.tagName?.toLowerCase();
      if (tag === "input" || tag === "textarea" || tag === "select") return;

      if (e.key === "Enter" && buffer.length >= 3) {
        e.preventDefault();
        const code = buffer.trim();
        buffer = "";
        clearTimeout(timer);

        // Try to match to active item or find by barcode
        const items = recRef.current?.items || [];
        const activeId = activeItem;

        // If an item is expanded, assign barcode to it
        if (activeId) {
          const curRec = recRef.current;
          const item = curRec?.items?.find(x => x.id === activeId);
          if (item) {
            const nr = { ...curRec, items: curRec.items.map(x => x.id === activeId ? { ...x, codigoBarras: code } : x) };
            recRef.current = nr;
            window.storage.set(keyRec(id), JSON.stringify(nr));
            setRec(nr);
            setGunToast({ code, matched: true, itemName: item.nombre });
            try { navigator.vibrate?.([100, 50, 100]); } catch(_) {}
            setTimeout(() => setGunToast(null), 3000);
            return;
          }
        }

        // If on buscar tab, put code in search
        if (tab === "buscar") {
          // Will be handled by BuscarCodigo's own listener
        }

        // Otherwise show toast with the captured code
        setGunToast({ code, matched: false, itemName: null });
        try { navigator.vibrate?.(100); } catch(_) {}
        setTimeout(() => setGunToast(null), 5000);
        return;
      }

      if (e.key.length === 1) {
        clearTimeout(timer);
        buffer += e.key;
        timer = setTimeout(() => { buffer = ""; }, 150); // Reset if no key in 150ms
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      clearTimeout(timer);
    };
  }, [activeItem, tab]);

  useEffect(() => {
    (async () => {
      try { const r = await window.storage.get(keyRec(id)); if (r?.value) { const p = JSON.parse(r.value); setRec(p); recRef.current = p; } } catch (_) {}
      setLoading(false);
    })();
  }, [id]);

  const save = async (nr) => {
    setRec(nr); recRef.current = nr;
    await window.storage.set(keyRec(id), JSON.stringify(nr));
    await onUpdate({ nItems: nr.items.length, proveedor: nr.proveedor, estado: nr.estado });
  };

  /* ── PROCESS ONE IMAGE ── */
  const processOne = async (queueId, onStep) => {
    const fileObj = fileMapRef.current[queueId];
    if (!fileObj) throw new Error("Archivo no disponible — selecciona de nuevo");
    
    onStep?.("Comprimiendo imagen...");
    const { base64, mediaType } = await compressImage(fileObj);
    if (!base64 || base64.length < 100) throw new Error("Imagen vacía o ilegible después de compresión");
    
    // Choose extraction mode
    const mode = scanModeRef.current;
    const result = mode === "preciso"
      ? await extraerFactura(base64, mediaType, onStep)
      : await extraerFacturaRapido(base64, mediaType, onStep);
      
    if (!result || !Array.isArray(result.items) || result.items.length === 0) {
      throw new Error("Sin productos detectados — verifica que la imagen contenga una factura legible");
    }
    return result;
  };

  /* ── QUEUE RUNNER (uses ref to avoid stale closures) ── */
  const runQueue = useCallback(async () => {
    if (processingRef.current) return;
    processingRef.current = true;

    const updateItem = (qid, patch) => {
      setQueue(prev => {
        const next = prev.map(x => x.id === qid ? { ...x, ...patch } : x);
        queueRef.current = next;
        return next;
      });
    };

    while (true) {
      const cur = queueRef.current;
      const nextIdx = cur.findIndex(x => x.status === "pending");
      if (nextIdx === -1) break;

      const item = cur[nextIdx];
      updateItem(item.id, { status: "processing", step: "Comprimiendo imagen..." });
      await new Promise(r => setTimeout(r, 60));

      try {
        const result = await processOne(item.id, (stepText) => {
          updateItem(item.id, { step: stepText });
        });

        const base = recRef.current;
        const newItems = (result.items || []).map((it, j) => ({
          id: uid(), item: it.item || String(base.items.length + j + 1).padStart(2, "0"),
          referencia: it.referencia || "—", nombre: it.nombre || "Sin nombre",
          unidad: it.unidad || "und", qty_factura: Number(it.qty_factura) || 0,
          qty_contada: 0, confianza: it._confianza || "alta", addedAt: Date.now(),
        }));
        const nr = {
          ...base,
          proveedor: base.proveedor || result.proveedor || "",
          nro_factura: base.nro_factura || result.nro_factura || "",
          facturas_procesadas: (base.facturas_procesadas || 0) + 1,
          items: [...base.items, ...newItems],
        };
        await save(nr);
        updateItem(item.id, { status: "done", count: newItems.length, step: null });
      } catch (err) {
        updateItem(item.id, { status: "error", errorMsg: err?.message || "Error desconocido", step: null });
      }
    }
    processingRef.current = false;
  }, []);

  /* ── RETRY ONE ── */
  const retryItem = useCallback((queueId) => {
    setQueue(prev => {
      const updated = prev.map(x => x.id === queueId ? { ...x, status: "pending", errorMsg: null, step: null } : x);
      queueRef.current = updated;
      return updated;
    });
    setTimeout(() => runQueue(), 50);
  }, [runQueue]);

  /* ── ADD FILES ── */
  const addFiles = async (files) => {
    const arr = Array.from(files).slice(0, 15);
    const entries = await Promise.all(arr.map(async (f) => {
      const qid = uid();
      fileMapRef.current[qid] = f;
      return { id: qid, preview: await fileToPreview(f), status: "pending", count: 0, errorMsg: null, step: null, mode: scanMode };
    }));
    setQueue(prev => {
      const nq = [...prev, ...entries];
      queueRef.current = nq;
      return nq;
    });
    setShowQueue(true);
    setTimeout(() => runQueue(), 50);
  };

  const editField = async (k, v) => { await save({ ...recRef.current, [k]: v }); };
  const setCantidad = async (iid, val) => {
    const n = Math.max(0, parseInt(val) || 0);
    await save({ ...recRef.current, items: recRef.current.items.map((it) => it.id === iid ? { ...it, qty_contada: n } : it) });
  };
  const delta = async (iid, d) => { const it = recRef.current.items.find((x) => x.id === iid); if (it) await setCantidad(iid, it.qty_contada + d); };
  const delItem = async (iid) => { await save({ ...recRef.current, items: recRef.current.items.filter((x) => x.id !== iid) }); };
  const setBarcode = async (iid, code) => {
    await save({ ...recRef.current, items: recRef.current.items.map((it) => it.id === iid ? { ...it, codigoBarras: code } : it) });
  };
  const setNota = async (iid, nota) => {
    await save({ ...recRef.current, items: recRef.current.items.map((it) => it.id === iid ? { ...it, nota } : it) });
  };

  /* ── IMPORT FROM PASTED JSON (supports multiple JSON objects at once) ── */
  const importFromJSON = async (jsonText) => {
    try {
      let clean = jsonText
        .replace(/^\uFEFF/, "")
        .replace(/[\u200B\u200C\u200D\uFEFF\u00A0]/g, "")
        .replace(/```json|```/g, "")
        .trim();

      // Extract ALL top-level JSON objects by tracking braces
      const jsonChunks = [];
      let depth = 0, start = -1;
      for (let i = 0; i < clean.length; i++) {
        if (clean[i] === "{") { if (depth === 0) start = i; depth++; }
        else if (clean[i] === "}") {
          depth--;
          if (depth === 0 && start !== -1) {
            jsonChunks.push(clean.slice(start, i + 1));
            start = -1;
          }
        }
      }
      if (jsonChunks.length === 0) throw new Error("No se encontro JSON");

      let totalCount = 0;
      let base = recRef.current;

      for (const chunk of jsonChunks) {
        let parsed;
        try { parsed = JSON.parse(chunk); } catch (_) { continue; }

        let items = [];
        let proveedor = "";
        let nro_factura = "";
        if (Array.isArray(parsed)) {
          items = parsed;
        } else if (parsed.items && Array.isArray(parsed.items)) {
          items = parsed.items;
          proveedor = parsed.proveedor || "";
          nro_factura = parsed.nro_factura || "";
        } else {
          items = [parsed];
        }
        if (items.length === 0) continue;

        const newItems = items.map((it, j) => ({
          id: uid(),
          item: it.item || String(base.items.length + j + 1).padStart(2, "0"),
          referencia: it.referencia || it.ref || it.codigo || it.sku || "—",
          nombre: it.nombre || it.descripcion || it.name || "Sin nombre",
          unidad: it.unidad || it.unit || "und",
          qty_factura: Number(it.qty_factura || it.cantidad || it.qty || it.cant) || 0,
          qty_contada: 0,
          confianza: "alta",
          nota: "",
          codigoBarras: "",
          addedAt: Date.now(),
        }));

        // POINT 10: Detect duplicates by reference — sum quantities
        const mergedItems = [...base.items];
        for (const ni of newItems) {
          const existing = mergedItems.find(e => e.referencia === ni.referencia && ni.referencia !== "—");
          if (existing) {
            existing.qty_factura += ni.qty_factura;
          } else {
            mergedItems.push(ni);
          }
        }

        base = {
          ...base,
          proveedor: base.proveedor || proveedor,
          nro_factura: base.nro_factura || nro_factura,
          facturas_procesadas: (base.facturas_procesadas || 0) + 1,
          items: mergedItems,
        };
        totalCount += newItems.length;
      }

      if (totalCount === 0) throw new Error("No se encontraron productos");
      await save(base);
      return { ok: true, count: totalCount };
    } catch (err) {
      return { ok: false, error: err.message || "JSON invalido" };
    }
  };
  const cerrar = async () => { if (!confirm("¿Cerrar esta recepción?")) return; await save({ ...recRef.current, estado: "cerrada" }); };

  if (loading || !rec) return <Loader />;
  const cerrada = rec.estado === "cerrada";
  const qPending = queue.filter((x) => x.status === "pending" || x.status === "processing").length;
  const qDone = queue.filter((x) => x.status === "done").length;
  const ok = rec.items.filter((it) => it.qty_contada === it.qty_factura && it.qty_factura > 0).length;
  const diff = rec.items.filter((it) => it.qty_contada !== it.qty_factura && it.qty_contada > 0).length;
  const pend = rec.items.filter((it) => it.qty_contada === 0 && it.qty_factura > 0).length;

  return (
    <div style={{ background: C.bg, minHeight: "100vh", fontFamily: SF }}>
      {/* NAV */}
      <div style={{ background: "rgba(255,255,255,0.92)", backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)", borderBottom: `1px solid ${C.separator}`, padding: "14px 16px", position: "sticky", top: 0, zIndex: 50 }}>
        <div style={{ maxWidth: 640, margin: "0 auto", display: "flex", alignItems: "center", gap: 12, justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <button onClick={onBack} style={{ background: "none", border: "none", color: C.orange, fontSize: 16, fontWeight: 600, cursor: "pointer", fontFamily: SF, display: "flex", alignItems: "center", gap: 4, padding: 0 }}>
              ‹ Volver
            </button>
          </div>
          <div style={{ flex: 1, textAlign: "center" }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: C.text, letterSpacing: -0.3 }}>{rec.nombre}</div>
            <div style={{ fontSize: 11, color: C.textTertiary, marginTop: 1 }}>{rec.items.length} productos · {rec.facturas_procesadas || 0} facturas</div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            {qPending > 0 && (
              <button onClick={() => setShowQueue(true)} style={{ background: C.orangePale, border: "none", borderRadius: 14, padding: "5px 10px", color: C.orange, fontFamily: SF, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                ⏳ {qPending}
              </button>
            )}
            {!cerrada && <button onClick={cerrar} style={{ background: "none", border: `1.5px solid ${C.separator}`, borderRadius: 14, padding: "5px 12px", color: C.textSecondary, fontFamily: SF, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Cerrar</button>}
          </div>
        </div>
      </div>

      {/* META STRIP */}
      <div style={{ background: C.white, borderBottom: `1px solid ${C.separator}`, padding: "12px 20px", display: "flex", gap: 24, flexWrap: "wrap", maxWidth: 640, margin: "0 auto" }}>
        <MetaField label="Proveedor" value={rec.proveedor} onChange={cerrada ? null : (v) => editField("proveedor", v)} placeholder="Nombre proveedor" />
        <MetaField label="N° Factura" value={rec.nro_factura} onChange={cerrada ? null : (v) => editField("nro_factura", v)} placeholder="F-00234" />
      </div>

      {/* TABS */}
      <div style={{ background: C.white, borderBottom: `1px solid ${C.separator}` }}>
        <div style={{ maxWidth: 640, margin: "0 auto", display: "flex" }}>
          {[["items", "Productos"], ["buscar", "Buscar código"], ["resumen", "Resumen"]].map(([t, label]) => (
            <button key={t} onClick={() => setTab(t)} style={{ flex: 1, padding: "12px 4px", background: "none", border: "none", borderBottom: `2.5px solid ${tab === t ? C.orange : "transparent"}`, color: tab === t ? C.orange : C.textSecondary, cursor: "pointer", fontFamily: SF, fontSize: 13, fontWeight: tab === t ? 600 : 400, transition: "all 0.2s" }}>
              {label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding: "16px 16px 200px", maxWidth: 640, margin: "0 auto" }}>

        {tab === "items" && (
          <>
            {rec.items.length > 0 && (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10, marginBottom: 16 }}>
                <MiniStat color={C.green} bg={C.greenPale} label="Conformes" value={ok} />
                <MiniStat color={C.amber} bg={C.amberPale} label="Diferencia" value={diff} />
                <MiniStat color={C.red} bg={C.redPale} label="Pendiente" value={pend} />
              </div>
            )}
            {rec.items.length === 0 && qPending === 0 && (
              <div style={{ textAlign: "center", padding: "60px 0" }}>
                <div style={{ fontSize: 48, marginBottom: 12 }}>📄</div>
                <div style={{ fontSize: 18, fontWeight: 600, color: C.text, marginBottom: 6 }}>Sin productos</div>
                <div style={{ fontSize: 14, color: C.textSecondary }}>Sube fotos de facturas para comenzar</div>
              </div>
            )}
            {qPending > 0 && (
              <div onClick={() => setShowQueue(true)} style={{ background: C.white, borderRadius: 14, padding: "14px 16px", marginBottom: 14, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "space-between", boxShadow: "0 1px 3px rgba(0,0,0,0.06)", border: `1px solid ${C.orangeMid}` }}>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: C.orange }}>Procesando facturas...</div>
                  <div style={{ fontSize: 13, color: C.textSecondary, marginTop: 2 }}>{qDone} listas · {qPending} en cola — toca para ver</div>
                </div>
                <div style={{ display: "flex", gap: 4 }}>
                  {[0,1,2].map(i => <div key={i} style={{ width: 7, height: 7, borderRadius: "50%", background: C.orange, animation: `bounce 1s ${i*0.2}s infinite` }} />)}
                </div>
              </div>
            )}
            <div style={{ display: "flex", flexDirection: "column", gap: 1, background: C.card, borderRadius: 16, overflow: "hidden", boxShadow: "0 1px 3px rgba(0,0,0,0.06)" }}>
              {rec.items.map((it, i) => (
                <ItemRow key={it.id} item={it} isLast={i === rec.items.length - 1}
                  active={activeItem === it.id}
                  onExpand={() => setActiveItem(activeItem === it.id ? null : it.id)}
                  onDelta={(d) => delta(it.id, d)}
                  onSet={(v) => setCantidad(it.id, v)}
                  onBarcode={(code) => setBarcode(it.id, code)}
                  onNota={(nota) => setNota(it.id, nota)}
                  onQuickConfirm={() => setCantidad(it.id, it.qty_factura)}
                  onDelete={() => delItem(it.id)}
                  cerrada={cerrada} />
              ))}
            </div>
          </>
        )}

        {tab === "buscar" && <BuscarCodigo items={rec.items} onSet={(iid, v) => setCantidad(iid, v)} onDelta={(iid, d) => delta(iid, d)} onBarcode={(iid, code) => setBarcode(iid, code)} onNota={(iid, nota) => setNota(iid, nota)} cerrada={cerrada} />}
        {tab === "resumen" && <ResumenView rec={rec} />}
      </div>

      {/* HIDDEN INPUTS */}
      <input ref={cameraRef} type="file" accept="image/*" capture="environment" style={{ display: "none" }} onChange={(e) => { if (e.target.files?.[0]) addFiles(e.target.files); e.target.value = ""; }} />
      <input ref={galleryRef} type="file" accept="image/*" multiple style={{ display: "none" }} onChange={(e) => { if (e.target.files?.length) addFiles(e.target.files); e.target.value = ""; }} />

      {/* BOTTOM BAR */}
      {!cerrada && (
        <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 60, background: "rgba(242,242,247,0.95)", backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)", borderTop: `1px solid ${C.separator}`, padding: "8px 16px 24px" }}>
          <div style={{ maxWidth: 500, margin: "0 auto" }}>
            {/* Mode selector */}
            <div style={{ display: "flex", gap: 4, marginBottom: 8, background: C.separator + "80", borderRadius: 10, padding: 3 }}>
              {[
                { id: "rapido", label: "⚡ Rápido", desc: "1 llamada · Sonnet" },
                { id: "preciso", label: "🎯 Preciso", desc: "3 pasos · Opus" },
              ].map(m => (
                <button key={m.id} onClick={() => setScanMode(m.id)}
                  style={{
                    flex: 1, padding: "6px 8px", border: "none", borderRadius: 8, cursor: "pointer", fontFamily: SF,
                    background: scanMode === m.id ? C.white : "transparent",
                    boxShadow: scanMode === m.id ? "0 1px 3px rgba(0,0,0,0.1)" : "none",
                    transition: "all 0.2s",
                  }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: scanMode === m.id ? C.text : C.textSecondary }}>{m.label}</div>
                  <div style={{ fontSize: 9, color: C.textTertiary, marginTop: 1 }}>{m.desc}</div>
                </button>
              ))}
            </div>
            {/* Action buttons */}
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => cameraRef.current.click()} style={{ flex: 1, background: C.white, border: `1.5px solid ${C.separator}`, borderRadius: 14, padding: "13px 0", color: C.text, fontFamily: SF, fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
                📷
              </button>
              <button onClick={() => setShowPaste(true)} style={{ flex: 1, background: C.white, border: `1.5px solid ${C.blue}40`, borderRadius: 14, padding: "13px 0", color: C.blue, fontFamily: SF, fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
                📋 Pegar
              </button>
              <button onClick={() => galleryRef.current.click()} style={{ flex: 2, background: C.orange, border: "none", borderRadius: 14, padding: "13px 0", color: "#fff", fontFamily: SF, fontSize: 14, fontWeight: 700, cursor: "pointer", boxShadow: `0 6px 18px ${C.orange}55` }}>
                🖼️ Galería
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QUEUE MODAL */}
      {showQueue && <QueueModal queue={queue} onClose={() => setShowQueue(false)} onRetry={retryItem} onClearDone={() => setQueue(q => { const n = q.filter(x => x.status !== "done"); queueRef.current = n; return n; })} />}

      {/* PASTE MODAL */}
      {showPaste && <PasteModal onClose={() => setShowPaste(false)} onImport={importFromJSON} />}

      {/* GUN BARCODE TOAST */}
      {gunToast && (
        <div style={{ position: "fixed", top: 80, left: 16, right: 16, zIndex: 400, animation: "slideDown 0.3s ease", maxWidth: 500, margin: "0 auto" }}>
          <div style={{ background: gunToast.matched ? C.green : C.blue, borderRadius: 16, padding: "16px 20px", boxShadow: "0 8px 30px rgba(0,0,0,0.3)", display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ fontSize: 28 }}>{gunToast.matched ? "✅" : "▮"}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.7)", fontWeight: 600 }}>
                {gunToast.matched ? "CÓDIGO ASIGNADO" : "CÓDIGO ESCANEADO"}
              </div>
              <div style={{ fontSize: 18, color: "#fff", fontWeight: 800, fontFamily: "monospace", marginTop: 2 }}>{gunToast.code}</div>
              {gunToast.matched && gunToast.itemName && (
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.8)", marginTop: 3 }}>→ {gunToast.itemName}</div>
              )}
              {!gunToast.matched && (
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.6)", marginTop: 3 }}>Expande un producto para asignarle este código</div>
              )}
            </div>
            <button onClick={() => setGunToast(null)} style={{ background: "rgba(255,255,255,0.2)", border: "none", borderRadius: "50%", width: 28, height: 28, color: "#fff", fontSize: 14, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
          </div>
        </div>
      )}

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; }
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; }
        input[type=number] { -moz-appearance: textfield; }
        @keyframes bounce { 0%,80%,100%{transform:scale(0.6);opacity:0.4} 40%{transform:scale(1);opacity:1} }
        @keyframes slideUp { from{transform:translateY(100%)} to{transform:translateY(0)} }
        @keyframes slideDown { from{transform:translateY(-100%);opacity:0} to{transform:translateY(0);opacity:1} }
        @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(6px)} to{opacity:1;transform:translateY(0)} }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.5} }
        @keyframes errorPulse { 0%,100%{box-shadow:0 0 0 0 rgba(255,59,48,0.4)} 50%{box-shadow:0 0 0 6px rgba(255,59,48,0)} }
      `}</style>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   BUSCAR POR CÓDIGO
══════════════════════════════════════════════════════════ */
function BuscarCodigo({ items, onSet, onDelta, onBarcode, onNota, cerrada }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [selected, setSelected] = useState(null);
  const [showScan, setShowScan] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [scanDone, setScanDone] = useState(false);
  const inputRef = useRef();
  const scanRef = useRef();

  useEffect(() => { inputRef.current?.focus(); }, []);
  useEffect(() => { if (showScan) setTimeout(() => scanRef.current?.focus(), 100); }, [showScan]);

  // Search: show ALL matches
  useEffect(() => {
    const q = query.trim().toLowerCase();
    if (!q) { setResults([]); setSelected(null); return; }
    const matches = items.filter(it =>
      it.referencia?.toLowerCase().includes(q) ||
      it.item?.toLowerCase().includes(q) ||
      it.nombre?.toLowerCase().includes(q) ||
      it.codigoBarras?.toLowerCase().includes(q)
    );
    setResults(matches);
    if (matches.length === 1) setSelected(matches[0]);
    else if (selected && !matches.find(m => m.id === selected.id)) setSelected(null);
  }, [query, items]);

  const selectItem = (it) => {
    setSelected(it);
    setShowScan(false);
    setScanDone(false);
  };

  const handleScan = (val) => {
    const code = val.trim();
    if (code.length >= 1 && selected) {
      onBarcode(selected.id, code);
      setSelected(prev => ({ ...prev, codigoBarras: code }));
      setScanDone(true);
      try { navigator.vibrate?.(100); } catch(_) {}
      setTimeout(() => setScanDone(false), 2000);
    }
  };

  const found = selected;
  const color = found ? statusColor(found.qty_factura, found.qty_contada) : C.orange;

  return (
    <div style={{ animation: "fadeIn 0.2s ease" }}>
      {/* Search bar */}
      <div style={{ position: "relative", marginBottom: 16 }}>
        <div style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", fontSize: 18, color: C.textTertiary }}>🔍</div>
        <input
          ref={inputRef}
          value={query}
          onChange={e => { setQuery(e.target.value); setSelected(null); }}
          placeholder="Escribe código, referencia o nombre..."
          style={{ width: "100%", background: C.white, border: `1.5px solid ${results.length > 0 ? C.orange + "60" : C.separator}`, borderRadius: 14, padding: "14px 14px 14px 44px", fontFamily: SF, fontSize: 15, color: C.text, outline: "none", boxShadow: "0 1px 3px rgba(0,0,0,0.06)", transition: "border-color 0.2s" }}
        />
        {query && (
          <button onClick={() => { setQuery(""); setResults([]); setSelected(null); setShowScan(false); inputRef.current?.focus(); }} style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)", background: C.textTertiary, border: "none", borderRadius: "50%", width: 20, height: 20, color: "#fff", fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", lineHeight: 1 }}>×</button>
        )}
      </div>

      {/* Result count */}
      {query && results.length > 0 && !found && (
        <div style={{ fontSize: 12, color: C.orange, fontWeight: 600, marginBottom: 8, paddingLeft: 4 }}>
          {results.length} resultado{results.length !== 1 ? "s" : ""} para "{query}" — toca uno para seleccionar
        </div>
      )}

      {/* No results */}
      {query && results.length === 0 && (
        <div style={{ background: C.white, borderRadius: 14, padding: "24px", textAlign: "center", boxShadow: "0 1px 3px rgba(0,0,0,0.06)" }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>🔎</div>
          <div style={{ fontSize: 16, fontWeight: 600, color: C.text, marginBottom: 4 }}>Sin resultados</div>
          <div style={{ fontSize: 13, color: C.textSecondary }}>No se encontró "{query}" en esta recepción</div>
        </div>
      )}

      {/* RESULTS LIST (when multiple matches and none selected) */}
      {query && results.length > 1 && !found && (
        <div style={{ background: C.white, borderRadius: 16, overflow: "hidden", boxShadow: "0 1px 3px rgba(0,0,0,0.06)", marginBottom: 14 }}>
          {results.map((it, i) => {
            const c = statusColor(it.qty_factura, it.qty_contada);
            return (
              <div key={it.id} onClick={() => selectItem(it)} style={{ padding: "12px 16px", display: "flex", alignItems: "center", gap: 12, borderBottom: i === results.length - 1 ? "none" : `1px solid ${C.separator}`, cursor: "pointer", background: C.white }}>
                <div style={{ width: 5, height: 36, borderRadius: 2, background: c, flexShrink: 0 }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: C.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{it.nombre}</div>
                  <div style={{ fontSize: 12, color: C.textTertiary, display: "flex", alignItems: "center", gap: 6 }}>
                    <span style={{ color: C.orange, fontWeight: 500 }}>{it.referencia}</span>
                    {it.codigoBarras && <span style={{ fontSize: 9, color: C.blue, fontFamily: "monospace", background: C.bluePale, padding: "0 4px", borderRadius: 3 }}>▮ {it.codigoBarras}</span>}
                  </div>
                </div>
                <div style={{ textAlign: "right", flexShrink: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: c }}>{it.qty_contada}<span style={{ fontSize: 11, color: C.textTertiary, fontWeight: 400 }}>/{it.qty_factura}</span></div>
                  <div style={{ fontSize: 9, color: c, fontWeight: 600 }}>{statusLabel(it.qty_factura, it.qty_contada)}</div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* SELECTED PRODUCT CARD */}
      {found && (
        <div style={{ background: C.white, borderRadius: 16, overflow: "hidden", boxShadow: "0 2px 12px rgba(0,0,0,0.08)", border: `2px solid ${color}30`, animation: "fadeIn 0.2s ease" }}>
          {/* Back to results */}
          {results.length > 1 && (
            <button onClick={() => setSelected(null)} style={{ width: "100%", padding: "8px", background: C.bg, border: "none", borderBottom: `1px solid ${C.separator}`, color: C.orange, fontFamily: SF, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
              ‹ Ver los {results.length} resultados
            </button>
          )}
          {/* Header */}
          <div style={{ background: color + "12", padding: "16px 18px", borderBottom: `1px solid ${color}20` }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div style={{ flex: 1, minWidth: 0, marginRight: 10 }}>
                <div style={{ fontSize: 11, color: color, fontWeight: 700, letterSpacing: 0.5, marginBottom: 3, textTransform: "uppercase" }}>#{found.item} · {found.referencia}</div>
                <div style={{ fontSize: 17, fontWeight: 700, color: C.text, lineHeight: 1.3 }}>{found.nombre}</div>
                <div style={{ fontSize: 13, color: C.textSecondary, marginTop: 4, display: "flex", alignItems: "center", gap: 6 }}>
                  {found.unidad}
                  {found.codigoBarras && <span style={{ fontSize: 10, color: C.blue, fontFamily: "monospace", background: C.bluePale, padding: "1px 5px", borderRadius: 4 }}>▮ {found.codigoBarras}</span>}
                </div>
              </div>
              <div style={{ background: color + "20", borderRadius: 10, padding: "6px 12px", textAlign: "center", flexShrink: 0 }}>
                <div style={{ fontSize: 10, color, fontWeight: 700, letterSpacing: 0.5 }}>{statusLabel(found.qty_factura, found.qty_contada).toUpperCase()}</div>
              </div>
            </div>
          </div>

          {/* Counters */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1px 1fr", padding: "16px 0" }}>
            <div style={{ textAlign: "center", padding: "0 16px" }}>
              <div style={{ fontSize: 12, color: C.textTertiary, fontWeight: 500, marginBottom: 4 }}>CANTIDAD FACTURA</div>
              <div style={{ fontSize: 36, fontWeight: 700, color: C.textSecondary }}>{found.qty_factura}</div>
            </div>
            <div style={{ background: C.separator }} />
            <div style={{ textAlign: "center", padding: "0 16px" }}>
              <div style={{ fontSize: 12, color, fontWeight: 600, marginBottom: 4 }}>CANTIDAD RECIBIDA</div>
              <div style={{ fontSize: 36, fontWeight: 700, color }}>{found.qty_contada}</div>
            </div>
          </div>

          {/* Controls */}
          {!cerrada && (
            <div style={{ padding: "0 16px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, justifyContent: "center" }}>
                <button onClick={() => { onDelta(found.id, -5); setSelected(prev => ({...prev, qty_contada: Math.max(0, prev.qty_contada - 5)})); }} style={ctrlBtn}>-5</button>
                <button onClick={() => { onDelta(found.id, -1); setSelected(prev => ({...prev, qty_contada: Math.max(0, prev.qty_contada - 1)})); }} style={ctrlBtn}>−</button>
                <input type="number" value={found.qty_contada}
                  onChange={e => { const n = Math.max(0, parseInt(e.target.value)||0); onSet(found.id, n); setSelected(prev => ({...prev, qty_contada: n})); }}
                  style={{ width: 80, height: 52, background: "#F9F9F9", border: `2px solid ${color}`, borderRadius: 12, color, fontSize: 28, fontWeight: 700, textAlign: "center", fontFamily: SF, outline: "none" }} />
                <button onClick={() => { onDelta(found.id, 1); setSelected(prev => ({...prev, qty_contada: prev.qty_contada + 1})); }} style={ctrlBtn}>+</button>
                <button onClick={() => { onDelta(found.id, 5); setSelected(prev => ({...prev, qty_contada: prev.qty_contada + 5})); }} style={ctrlBtn}>+5</button>
              </div>
              <button onClick={() => { onSet(found.id, found.qty_factura); setSelected(prev => ({...prev, qty_contada: prev.qty_factura})); }}
                style={{ width: "100%", marginTop: 12, background: color + "15", border: "none", borderRadius: 12, padding: "11px", color, fontFamily: SF, fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
                Marcar conforme = {found.qty_factura}
              </button>

              {/* BARCODE BUTTONS */}
              {!showScan && (
                <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                  <button onClick={() => setShowCamera(true)}
                    style={{ flex: 2, background: found.codigoBarras ? C.bluePale : "#E8F0FE", border: `2px dashed ${C.blue}`, borderRadius: 12, padding: "14px", color: C.blue, fontFamily: SF, fontSize: 14, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
                    📷 {found.codigoBarras ? found.codigoBarras : "Escanear con cámara"}
                  </button>
                  <button onClick={() => setShowScan(true)}
                    style={{ flex: 1, background: C.white, border: `1.5px solid ${C.separator}`, borderRadius: 12, padding: "14px 8px", color: C.textSecondary, fontFamily: SF, fontSize: 12, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 4 }}>
                    ⌨️ Manual
                  </button>
                </div>
              )}

              {/* MANUAL INPUT */}
              {showScan && (
                <div style={{ marginTop: 10, background: C.white, border: `2px solid ${scanDone ? C.green : C.blue}`, borderRadius: 12, padding: 14, animation: "fadeIn 0.15s ease" }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: scanDone ? C.green : C.blue, marginBottom: 8 }}>
                    {scanDone ? "✓ CÓDIGO REGISTRADO" : "▮ ESCRIBIR CÓDIGO DE BARRAS"}
                  </div>
                  <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                    <input ref={scanRef} type="text" autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck="false"
                      defaultValue={found.codigoBarras || ""}
                      onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); handleScan(e.target.value); } }}
                      placeholder="Escribe o pistola aqui..."
                      style={{ flex: 1, background: scanDone ? C.greenPale : "#F8FAFF", border: `2px solid ${scanDone ? C.green : C.blue + "40"}`, borderRadius: 10, padding: "14px 12px", fontFamily: "'SF Mono', 'Courier New', monospace", fontSize: 18, color: C.text, outline: "none" }} />
                    <button onClick={() => { if (scanRef.current?.value?.trim().length >= 1) handleScan(scanRef.current.value); }}
                      style={{ background: scanDone ? C.green : C.blue, border: "none", borderRadius: 10, padding: "14px 16px", color: "#fff", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: SF }}>
                      {scanDone ? "✓" : "OK"}
                    </button>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8 }}>
                    <div style={{ fontSize: 11, color: found.codigoBarras ? C.green : C.textTertiary, fontWeight: 600 }}>{found.codigoBarras ? `✓ ${found.codigoBarras}` : "Pistola o teclado"}</div>
                    <div style={{ display: "flex", gap: 10 }}>
                      {found.codigoBarras && <button onClick={() => { onBarcode(found.id, ""); setSelected(prev => ({...prev, codigoBarras: ""})); }} style={{ fontSize: 11, color: C.red, background: "none", border: "none", cursor: "pointer", fontFamily: SF, fontWeight: 600 }}>Borrar</button>}
                      <button onClick={() => setShowScan(false)} style={{ fontSize: 11, color: C.textTertiary, background: "none", border: "none", cursor: "pointer", fontFamily: SF, fontWeight: 600 }}>Cerrar</button>
                    </div>
                  </div>
                </div>
              )}

              {showCamera && <CameraScanner onScan={(code) => { handleScan(code); setShowCamera(false); }} onClose={() => setShowCamera(false)} />}
            </div>
          )}
          <div style={{ height: 16 }} />
        </div>
      )}

      {/* ALL PRODUCTS (when no query) */}
      {!query && items.length > 0 && (
        <div>
          <div style={{ fontSize: 13, color: C.textTertiary, marginBottom: 10, paddingLeft: 4 }}>Todos los productos ({items.length})</div>
          <div style={{ background: C.white, borderRadius: 16, overflow: "hidden", boxShadow: "0 1px 3px rgba(0,0,0,0.06)" }}>
            {items.map((it, i) => {
              const c = statusColor(it.qty_factura, it.qty_contada);
              return (
                <div key={it.id} onClick={() => { setQuery(it.referencia !== "—" ? it.referencia : it.nombre); }} style={{ padding: "12px 16px", display: "flex", alignItems: "center", gap: 12, borderBottom: i === items.length - 1 ? "none" : `1px solid ${C.separator}`, cursor: "pointer" }}>
                  <div style={{ width: 6, height: 6, borderRadius: "50%", background: c, flexShrink: 0 }} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 14, fontWeight: 600, color: C.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{it.nombre}</div>
                    <div style={{ fontSize: 12, color: C.textTertiary, display: "flex", alignItems: "center", gap: 4 }}>
                      {it.referencia}
                      {it.codigoBarras && <span style={{ fontSize: 9, color: C.blue, fontFamily: "monospace" }}>▮</span>}
                    </div>
                  </div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: c }}>{it.qty_contada}<span style={{ fontSize: 11, color: C.textTertiary, fontWeight: 400 }}>/{it.qty_factura}</span></div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}


/* ══════════════════════════════════════════════════════════
   CAMERA BARCODE SCANNER — Optimized for Android
   Photo capture → BarcodeDetector → multi-pass detection
══════════════════════════════════════════════════════════ */
function CameraScanner({ onScan, onClose }) {
  const [status, setStatus] = useState("ready");
  const [lastCode, setLastCode] = useState(null);
  const [errorMsg, setErrorMsg] = useState("");
  const [attempts, setAttempts] = useState(0);
  const fileRef = useRef();
  const detectorRef = useRef(null);

  useEffect(() => {
    if (!("BarcodeDetector" in window)) { setStatus("notsupported"); return; }
    try {
      detectorRef.current = new BarcodeDetector({
        formats: ["ean_13","ean_8","upc_a","upc_e","code_128","code_39","code_93","codabar","itf","qr_code","data_matrix","aztec","pdf417"]
      });
      setTimeout(() => fileRef.current?.click(), 300);
    } catch (e) { setStatus("notsupported"); }
  }, []);

  const processImage = async (file) => {
    if (!file || !detectorRef.current) return;
    setStatus("scanning");
    setAttempts(prev => prev + 1);
    try {
      const bitmap = await createImageBitmap(file);
      let barcodes = await detectorRef.current.detect(bitmap);

      if (barcodes.length === 0) {
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        const cropW = Math.floor(bitmap.width * 0.6);
        const cropH = Math.floor(bitmap.height * 0.6);
        canvas.width = cropW; canvas.height = cropH;
        ctx.drawImage(bitmap, (bitmap.width-cropW)/2, (bitmap.height-cropH)/2, cropW, cropH, 0, 0, cropW, cropH);
        barcodes = await detectorRef.current.detect(await createImageBitmap(canvas));
      }
      if (barcodes.length === 0) {
        const canvas = document.createElement("canvas");
        canvas.width = bitmap.width; canvas.height = bitmap.height;
        const ctx = canvas.getContext("2d");
        ctx.filter = "contrast(1.8) brightness(1.1) grayscale(1)";
        ctx.drawImage(bitmap, 0, 0); ctx.filter = "none";
        barcodes = await detectorRef.current.detect(await createImageBitmap(canvas));
      }

      if (barcodes.length > 0) {
        const code = barcodes[0].rawValue;
        setLastCode(code); setStatus("success");
        try { navigator.vibrate?.([100,50,100]); } catch(_) {}
        setTimeout(() => onScan(code), 800);
      } else {
        setErrorMsg(attempts >= 2
          ? "Acerca mas la camara. Buena luz, codigo completo en la foto, sin reflejos."
          : "No se detecto codigo. Acercate mas y enfoca bien.");
        setStatus("error");
      }
    } catch (e) { setErrorMsg("Error al procesar. Intenta de nuevo."); setStatus("error"); }
  };

  const retry = () => { setStatus("ready"); setErrorMsg(""); setTimeout(() => fileRef.current?.click(), 200); };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.95)", zIndex: 300, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", fontFamily: SF }}>
      <input ref={fileRef} type="file" accept="image/*" capture="environment" style={{ display: "none" }}
        onChange={e => { if (e.target.files?.[0]) processImage(e.target.files[0]); e.target.value = ""; }} />
      <button onClick={onClose} style={{ position: "absolute", top: 20, right: 20, background: "rgba(255,255,255,0.15)", border: "none", borderRadius: "50%", width: 44, height: 44, color: "#fff", fontSize: 22, cursor: "pointer", zIndex: 10, display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>

      {status === "ready" && (
        <div style={{ textAlign: "center", padding: 30 }}>
          <div style={{ width: 100, height: 100, background: "rgba(255,107,0,0.15)", borderRadius: 30, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 50, margin: "0 auto 20px" }}>📷</div>
          <div style={{ fontSize: 20, color: "#fff", fontWeight: 700, marginBottom: 8 }}>Escanear codigo de barras</div>
          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", marginBottom: 24, maxWidth: 280, lineHeight: 1.5 }}>Enfoca el codigo de barras. Acercate lo mas posible.</div>
          <button onClick={() => fileRef.current?.click()} style={{ background: C.orange, border: "none", borderRadius: 16, padding: "18px 50px", color: "#fff", fontSize: 18, fontWeight: 700, cursor: "pointer", fontFamily: SF, boxShadow: "0 6px 25px rgba(255,107,0,0.4)", margin: "0 auto" }}>
            📷 Abrir camara
          </button>
          <div style={{ marginTop: 16, fontSize: 11, color: "rgba(255,255,255,0.3)" }}>Buena luz + camara cerca = lectura instantanea</div>
        </div>
      )}

      {status === "scanning" && (
        <div style={{ textAlign: "center" }}>
          <div style={{ width: 80, height: 80, borderRadius: 24, border: "4px solid #FF6B00", borderTopColor: "transparent", animation: "spin 0.8s linear infinite", margin: "0 auto 20px" }} />
          <div style={{ fontSize: 16, color: "#fff", fontWeight: 600 }}>Analizando imagen...</div>
        </div>
      )}

      {status === "success" && (
        <div style={{ textAlign: "center", animation: "fadeIn 0.3s ease" }}>
          <div style={{ width: 100, height: 100, background: "rgba(52,199,89,0.2)", borderRadius: 50, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 50, margin: "0 auto 20px" }}>✅</div>
          <div style={{ fontSize: 20, color: "#34C759", fontWeight: 700, marginBottom: 8 }}>Codigo detectado</div>
          <div style={{ fontSize: 24, color: "#fff", fontWeight: 800, fontFamily: "monospace", background: "rgba(255,255,255,0.1)", padding: "12px 24px", borderRadius: 12 }}>{lastCode}</div>
        </div>
      )}

      {status === "error" && (
        <div style={{ textAlign: "center", padding: 30, animation: "fadeIn 0.2s ease" }}>
          <div style={{ width: 80, height: 80, background: "rgba(255,59,48,0.15)", borderRadius: 24, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 40, margin: "0 auto 16px" }}>🔍</div>
          <div style={{ fontSize: 17, color: "#fff", fontWeight: 700, marginBottom: 8 }}>No se encontro codigo</div>
          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", marginBottom: 24, maxWidth: 300, lineHeight: 1.5 }}>{errorMsg}</div>
          <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
            <button onClick={retry} style={{ background: C.orange, border: "none", borderRadius: 14, padding: "14px 30px", color: "#fff", fontSize: 15, fontWeight: 700, cursor: "pointer", fontFamily: SF }}>📷 Intentar de nuevo</button>
            <button onClick={onClose} style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.2)", borderRadius: 14, padding: "14px 20px", color: "rgba(255,255,255,0.7)", fontSize: 14, cursor: "pointer", fontFamily: SF }}>Cerrar</button>
          </div>
          {attempts >= 2 && <div style={{ marginTop: 16, fontSize: 11, color: "rgba(255,255,255,0.3)", maxWidth: 280, lineHeight: 1.4 }}>Activa el flash · No inclines el codigo · Evita reflejos · Codigo completo en la foto</div>}
        </div>
      )}

      {status === "notsupported" && (
        <div style={{ textAlign: "center", padding: 30 }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>⚠️</div>
          <div style={{ fontSize: 15, color: "#fff", fontWeight: 600, marginBottom: 8 }}>Escaner no disponible</div>
          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", marginBottom: 20 }}>Actualiza Chrome o usa modo manual.</div>
          <button onClick={onClose} style={{ background: C.orange, border: "none", borderRadius: 12, padding: "12px 24px", color: "#fff", fontFamily: SF, fontSize: 14, fontWeight: 600, cursor: "pointer" }}>Cerrar</button>
        </div>
      )}
    </div>
  );
}


const ctrlBtn = { width: 44, height: 44, background: C.bg, border: `1px solid ${C.separator}`, borderRadius: 12, color: C.text, fontSize: 16, fontWeight: 600, cursor: "pointer", fontFamily: SF };

/* ══════════════════════════════════════════════════════════
   QUEUE MODAL — WITH CORNER ERROR BADGES
══════════════════════════════════════════════════════════ */
function QueueModal({ queue, onClose, onRetry, onClearDone }) {
  const [selectedId, setSelectedId] = useState(null);
  const done = queue.filter(x => x.status === "done").length;
  const errors = queue.filter(x => x.status === "error").length;
  const total = queue.length;
  const pct = total ? Math.round((done / total) * 100) : 0;
  const selectedItem = queue.find(x => x.id === selectedId);
  const diag = selectedItem?.status === "error" ? diagnosticarError(selectedItem.errorMsg) : null;

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 200, display: "flex", alignItems: "flex-end", justifyContent: "center" }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ background: C.bg, borderRadius: "24px 24px 0 0", width: "100%", maxWidth: 540, maxHeight: "88vh", display: "flex", flexDirection: "column", animation: "slideUp 0.3s cubic-bezier(0.34,1.3,0.64,1)" }}>

        <div style={{ width: 36, height: 4, background: C.separator, borderRadius: 2, margin: "12px auto 0" }} />

        <div style={{ padding: "14px 20px 10px", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontSize: 20, fontWeight: 700, color: C.text, letterSpacing: -0.3 }}>Facturas</div>
            <div style={{ fontSize: 13, color: C.textSecondary, marginTop: 2 }}>
              {done}/{total} listas · {queue.reduce((s, x) => s + (x.count||0), 0)} productos
              {errors > 0 && <span style={{ color: C.red, fontWeight: 600 }}> · {errors} con error</span>}
            </div>
          </div>
          <button onClick={onClose} style={{ background: C.separator, border: "none", borderRadius: "50%", width: 30, height: 30, color: C.textSecondary, fontSize: 16, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>×</button>
        </div>

        <div style={{ height: 4, background: C.separator, margin: "0 20px 14px", borderRadius: 3, overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${pct}%`, background: `linear-gradient(90deg,${C.orange},${C.orangeLight})`, borderRadius: 3, transition: "width 0.5s ease" }} />
        </div>

        <div style={{ overflowY: "auto", flex: 1, padding: "0 16px" }}>

          {/* PHOTO GRID — ERROR CORNER BADGE */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(100px,1fr))", gap: 10, paddingBottom: 14 }}>
            {queue.map((item, i) => {
              const isErr = item.status === "error";
              const isDone = item.status === "done";
              const isProc = item.status === "processing";
              const isSelected = selectedId === item.id;
              const errDiag = isErr ? diagnosticarError(item.errorMsg) : null;

              return (
                <div key={item.id}
                  onClick={() => isErr ? setSelectedId(isSelected ? null : item.id) : null}
                  style={{
                    borderRadius: 14, overflow: "hidden",
                    border: `2.5px solid ${isSelected ? C.red : isErr ? C.red+"50" : isDone ? C.green+"50" : isProc ? C.orange+"50" : C.separator}`,
                    aspectRatio: "3/4", position: "relative", background: "#ddd",
                    cursor: isErr ? "pointer" : "default",
                    transform: isSelected ? "scale(0.96)" : "scale(1)",
                    transition: "transform 0.15s, border-color 0.15s",
                    animation: isErr && !isSelected ? "errorPulse 2s infinite" : "none",
                  }}>
                  <img src={item.preview} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
                  <div style={{ position: "absolute", inset: 0, background: isErr ? "rgba(255,59,48,0.25)" : isDone ? "rgba(52,199,89,0.15)" : isProc ? "rgba(255,107,0,0.1)" : "rgba(0,0,0,0.3)", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: 7 }}>
                    <div style={{ textAlign: "right" }}>
                      {isDone && <span style={{ background: C.green, color: "#fff", borderRadius: 6, fontSize: 10, fontWeight: 700, padding: "2px 5px" }}>✓</span>}
                      {isProc && <span style={{ background: C.orange, color: "#fff", borderRadius: 6, fontSize: 10, fontWeight: 700, padding: "2px 5px", display: "inline-block", animation: "spin 1.5s linear infinite" }}>↻</span>}
                    </div>
                    <div>
                      <div style={{ fontSize: 10, color: "#fff", fontWeight: 600 }}>Foto {i + 1}</div>
                      {isDone && <div style={{ fontSize: 11, color: "#fff", fontWeight: 700 }}>{item.count} items</div>}
                      {isProc && <div style={{ fontSize: 9, color: "#fff", opacity: 0.85 }}>{item.step || "Procesando..."}</div>}
                      {item.status === "pending" && <div style={{ fontSize: 9, color: "#fff", opacity: 0.6 }}>En cola</div>}
                    </div>
                  </div>

                  {/* ═══ CORNER ERROR BADGE — TOCA PARA VER PROBLEMA ═══ */}
                  {isErr && (
                    <div style={{
                      position: "absolute",
                      top: 0, right: 0,
                      width: 44, height: 44,
                      cursor: "pointer",
                      zIndex: 5,
                    }}>
                      {/* Triangle corner background */}
                      <div style={{
                        position: "absolute", top: 0, right: 0,
                        width: 0, height: 0,
                        borderLeft: "44px solid transparent",
                        borderTop: `44px solid ${C.red}`,
                      }} />
                      {/* Icon */}
                      <div style={{
                        position: "absolute", top: 4, right: 5,
                        fontSize: 16,
                        filter: "drop-shadow(0 1px 2px rgba(0,0,0,0.3))",
                        lineHeight: 1,
                      }}>
                        {errDiag?.icon || "⚠️"}
                      </div>
                      {/* Mini tooltip on selected */}
                      {isSelected && (
                        <div style={{
                          position: "absolute",
                          top: 44, right: 0,
                          background: C.red,
                          color: "#fff",
                          fontSize: 9,
                          fontWeight: 600,
                          fontFamily: SF,
                          padding: "3px 7px",
                          borderRadius: 6,
                          whiteSpace: "nowrap",
                          boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
                          zIndex: 10,
                        }}>
                          {errDiag?.titulo || "Error"}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* ERROR DIAGNOSIS PANEL (expanded) */}
          {diag && selectedItem && (
            <div style={{ background: C.white, borderRadius: 18, marginBottom: 14, overflow: "hidden", boxShadow: "0 2px 12px rgba(255,59,48,0.12)", border: `1.5px solid ${C.red}25`, animation: "fadeIn 0.2s ease" }}>
              <div style={{ background: `linear-gradient(135deg, ${C.red}18, ${C.red}08)`, padding: "16px 18px", borderBottom: `1px solid ${C.red}15` }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <div style={{ width: 44, height: 44, borderRadius: 14, background: C.redPale, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>{diag.icon}</div>
                  <div>
                    <div style={{ fontSize: 16, fontWeight: 700, color: C.text }}>{diag.titulo}</div>
                    <div style={{ fontSize: 12, color: C.red, fontWeight: 500, marginTop: 2 }}>
                      Foto {queue.findIndex(x => x.id === selectedItem.id) + 1}
                    </div>
                  </div>
                </div>
              </div>

              <div style={{ padding: "14px 18px 0" }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: C.textTertiary, letterSpacing: 0.5, textTransform: "uppercase", marginBottom: 5 }}>¿Qué pasó?</div>
                <div style={{ fontSize: 14, color: C.textSecondary, lineHeight: 1.5 }}>{diag.causa}</div>
              </div>

              <div style={{ padding: "12px 18px 0" }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: C.textTertiary, letterSpacing: 0.5, textTransform: "uppercase", marginBottom: 5 }}>¿Qué hacer?</div>
                <div style={{ fontSize: 14, color: C.text, fontWeight: 500, lineHeight: 1.5, background: diag.needsNewPhoto ? C.amberPale : C.greenPale, borderRadius: 10, padding: "10px 12px" }}>
                  {diag.needsNewPhoto ? "📷 " : "↺ "}{diag.solucion}
                </div>
              </div>

              {/* Technical detail (collapsible) */}
              {selectedItem.errorMsg && (
                <details style={{ padding: "8px 18px 0" }}>
                  <summary style={{ fontSize: 11, color: C.textTertiary, cursor: "pointer", fontFamily: SF }}>Ver detalle técnico</summary>
                  <div style={{ fontSize: 11, color: C.textTertiary, marginTop: 4, padding: "6px 8px", background: "#F5F5F5", borderRadius: 6, fontFamily: "monospace", wordBreak: "break-all" }}>
                    {selectedItem.errorMsg}
                  </div>
                </details>
              )}

              <div style={{ padding: "14px 18px 18px", display: "flex", gap: 8 }}>
                {(diag.accion === "retry" || diag.accion === "retry_or_photo") && (
                  <button onClick={() => { onRetry(selectedItem.id); setSelectedId(null); }}
                    style={{ flex: 1, background: C.orange, border: "none", borderRadius: 12, padding: "12px", color: "#fff", fontFamily: SF, fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
                    ↺ Reintentar foto
                  </button>
                )}
                {(diag.accion === "new_photo" || diag.accion === "retry_or_photo") && (
                  <button onClick={() => { setSelectedId(null); onClose(); }}
                    style={{ flex: 1, background: C.bg, border: `1px solid ${C.separator}`, borderRadius: 12, padding: "12px", color: C.text, fontFamily: SF, fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
                    📷 Tomar otra foto
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ padding: "10px 16px 28px", borderTop: `1px solid ${C.separator}`, display: "flex", gap: 8 }}>
          {errors > 0 && !selectedId && (
            <button onClick={() => queue.filter(x => x.status === "error").forEach(x => onRetry(x.id))}
              style={{ flex: 1, background: C.redPale, border: "none", borderRadius: 12, padding: "12px", color: C.red, fontFamily: SF, fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
              ↺ Reintentar todos los errores ({errors})
            </button>
          )}
          {done > 0 && (
            <button onClick={onClearDone}
              style={{ flex: 1, background: C.bg, border: `1px solid ${C.separator}`, borderRadius: 12, padding: "12px", color: C.textSecondary, fontFamily: SF, fontSize: 13, fontWeight: 500, cursor: "pointer" }}>
              Limpiar listas ({done})
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   PASTE MODAL — Pegar JSON desde Claude
══════════════════════════════════════════════════════════ */
function PasteModal({ onClose, onImport }) {
  const [text, setText] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const textRef = useRef();

  useEffect(() => { setTimeout(() => textRef.current?.focus(), 100); }, []);

  const handlePaste = async () => {
    if (!text.trim()) return;
    setLoading(true);
    const res = await onImport(text);
    setResult(res);
    setLoading(false);
    if (res.ok) {
      setTimeout(() => onClose(), 1200);
    }
  };

  const handleClipboard = async () => {
    try {
      const clip = await navigator.clipboard.readText();
      if (clip) {
        setText(clip);
        // Auto-import immediately
        setLoading(true);
        const res = await onImport(clip);
        setResult(res);
        setLoading(false);
        if (res.ok) setTimeout(() => onClose(), 1200);
      }
    } catch (_) {
      // Clipboard API may not be available
    }
  };

  const ejemplo = `{"proveedor":"PAVECA","nro_factura":"F-0842","items":[
  {"referencia":"TUB-PVC-1/2","nombre":"Tubo PVC 1/2","unidad":"und","qty_factura":50},
  {"referencia":"COD-HG-3/4","nombre":"Codo HG 3/4","unidad":"und","qty_factura":100}
]}`;

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 200, display: "flex", alignItems: "flex-end", justifyContent: "center" }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ background: C.bg, borderRadius: "24px 24px 0 0", width: "100%", maxWidth: 540, maxHeight: "90vh", display: "flex", flexDirection: "column", animation: "slideUp 0.3s cubic-bezier(0.34,1.3,0.64,1)" }}>

        <div style={{ width: 36, height: 4, background: C.separator, borderRadius: 2, margin: "12px auto 0" }} />

        <div style={{ padding: "14px 20px 10px", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontSize: 20, fontWeight: 700, color: C.text, letterSpacing: -0.3 }}>📋 Pegar productos</div>
            <div style={{ fontSize: 13, color: C.textSecondary, marginTop: 2 }}>Pega el JSON que te dio Claude</div>
          </div>
          <button onClick={onClose} style={{ background: C.separator, border: "none", borderRadius: "50%", width: 30, height: 30, color: C.textSecondary, fontSize: 16, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>×</button>
        </div>

        <div style={{ overflowY: "auto", flex: 1, padding: "0 16px 16px" }}>

          {/* Clipboard button */}
          <button onClick={handleClipboard} style={{ width: "100%", background: C.bluePale, border: `1px solid ${C.blue}30`, borderRadius: 12, padding: "10px", color: C.blue, fontFamily: SF, fontSize: 13, fontWeight: 600, cursor: "pointer", marginBottom: 10, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
            📎 Pegar desde portapapeles
          </button>

          {/* Text area */}
          <textarea
            ref={textRef}
            value={text}
            onChange={e => { setText(e.target.value); setResult(null); }}
            placeholder={`Pega aquí el JSON...\n\nEjemplo:\n${ejemplo}`}
            style={{
              width: "100%", minHeight: 200, background: C.white, border: `1.5px solid ${result?.ok === false ? C.red : text ? C.blue + "60" : C.separator}`,
              borderRadius: 14, padding: 14, fontFamily: "'SF Mono', 'Fira Code', monospace", fontSize: 12, color: C.text,
              outline: "none", resize: "vertical", lineHeight: 1.5, transition: "border-color 0.2s",
            }}
          />

          {/* Preview count */}
          {text.trim() && !result && (() => {
            try {
              const clean = text.replace(/^\uFEFF/, "").replace(/[\u200B\u200C\u200D\uFEFF\u00A0]/g, "").replace(/```json|```/g, "").trim();
              const chunks = [];
              let d = 0, s = -1;
              for (let i = 0; i < clean.length; i++) {
                if (clean[i] === "{") { if (d === 0) s = i; d++; }
                else if (clean[i] === "}") { d--; if (d === 0 && s !== -1) { chunks.push(clean.slice(s, i + 1)); s = -1; } }
              }
              let total = 0, facts = 0;
              for (const c of chunks) {
                try {
                  const obj = JSON.parse(c);
                  const items = Array.isArray(obj) ? obj : (obj.items || [obj]);
                  total += items.length;
                  facts++;
                } catch(_) {}
              }
              if (total === 0) throw new Error("no items");
              return (
                <div style={{ marginTop: 8, fontSize: 12, color: C.green, fontWeight: 600 }}>
                  {facts > 1 ? `✓ ${facts} facturas — ${total} productos detectados` : `✓ JSON valido — ${total} producto${total !== 1 ? "s" : ""} detectado${total !== 1 ? "s" : ""}`}
                </div>
              );
            } catch (_) {
              return (
                <div style={{ marginTop: 8, fontSize: 12, color: C.red, fontWeight: 600 }}>
                  ✗ JSON invalido — verifica el formato
                </div>
              );
            }
          })()}

          {/* Result feedback */}
          {result?.ok && (
            <div style={{ marginTop: 12, background: C.greenPale, borderRadius: 12, padding: "14px 16px", display: "flex", alignItems: "center", gap: 10, animation: "fadeIn 0.2s ease" }}>
              <div style={{ fontSize: 24 }}>✅</div>
              <div>
                <div style={{ fontSize: 15, fontWeight: 700, color: C.green }}>¡{result.count} productos importados!</div>
                <div style={{ fontSize: 12, color: C.textSecondary, marginTop: 2 }}>Cerrando...</div>
              </div>
            </div>
          )}
          {result?.ok === false && (
            <div style={{ marginTop: 12, background: C.redPale, borderRadius: 12, padding: "14px 16px", animation: "fadeIn 0.2s ease" }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: C.red, marginBottom: 4 }}>Error al importar</div>
              <div style={{ fontSize: 13, color: C.textSecondary }}>{result.error}</div>
            </div>
          )}

          {/* Help section */}
          <details style={{ marginTop: 14 }}>
            <summary style={{ fontSize: 13, color: C.blue, cursor: "pointer", fontFamily: SF, fontWeight: 600 }}>¿Cómo funciona?</summary>
            <div style={{ marginTop: 8, fontSize: 12, color: C.textSecondary, lineHeight: 1.6, background: C.white, borderRadius: 10, padding: 12 }}>
              <strong style={{ color: C.text }}>1.</strong> Mándame la foto de la factura aquí en el chat<br/>
              <strong style={{ color: C.text }}>2.</strong> Te respondo con el JSON de los productos<br/>
              <strong style={{ color: C.text }}>3.</strong> Copias el JSON y lo pegas aquí<br/>
              <strong style={{ color: C.text }}>4.</strong> Los productos se agregan a la recepción<br/><br/>
              <strong style={{ color: C.orange }}>Formato que acepta:</strong><br/>
              <code style={{ fontSize: 11, background: "#F0F0F0", padding: "2px 4px", borderRadius: 4 }}>referencia</code> o <code style={{ fontSize: 11, background: "#F0F0F0", padding: "2px 4px", borderRadius: 4 }}>codigo</code> o <code style={{ fontSize: 11, background: "#F0F0F0", padding: "2px 4px", borderRadius: 4 }}>sku</code><br/>
              <code style={{ fontSize: 11, background: "#F0F0F0", padding: "2px 4px", borderRadius: 4 }}>nombre</code> o <code style={{ fontSize: 11, background: "#F0F0F0", padding: "2px 4px", borderRadius: 4 }}>descripcion</code><br/>
              <code style={{ fontSize: 11, background: "#F0F0F0", padding: "2px 4px", borderRadius: 4 }}>qty_factura</code> o <code style={{ fontSize: 11, background: "#F0F0F0", padding: "2px 4px", borderRadius: 4 }}>cantidad</code> o <code style={{ fontSize: 11, background: "#F0F0F0", padding: "2px 4px", borderRadius: 4 }}>cant</code>
            </div>
          </details>
        </div>

        {/* Action button */}
        <div style={{ padding: "10px 16px 28px", borderTop: `1px solid ${C.separator}` }}>
          <button onClick={handlePaste} disabled={!text.trim() || loading || result?.ok}
            style={{
              width: "100%", background: text.trim() && !loading ? C.blue : C.separator,
              border: "none", borderRadius: 14, padding: "14px", color: text.trim() && !loading ? "#fff" : C.textTertiary,
              fontFamily: SF, fontSize: 15, fontWeight: 700, cursor: text.trim() ? "pointer" : "default",
              transition: "background 0.2s",
            }}>
            {loading ? "Importando..." : result?.ok ? "✓ Importado" : "Importar productos"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   ITEM ROW
══════════════════════════════════════════════════════════ */
function ItemRow({ item, active, isLast, onExpand, onDelta, onSet, onBarcode, onNota, onQuickConfirm, onDelete, cerrada }) {
  const color = statusColor(item.qty_factura, item.qty_contada);
  const confianza = item.confianza || "alta";
  const confColor = confianza === "alta" ? C.green : confianza === "media" ? C.amber : C.red;
  const [showScan, setShowScan] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [scanDone, setScanDone] = useState(false);
  const [editNota, setEditNota] = useState(false);
  const scanRef = useRef();
  const notaRef = useRef();

  useEffect(() => { if (showScan) setTimeout(() => scanRef.current?.focus(), 100); }, [showScan]);
  useEffect(() => { if (editNota) setTimeout(() => notaRef.current?.focus(), 100); }, [editNota]);

  const handleScan = (val) => {
    const code = val.trim();
    if (code.length >= 1) {
      onBarcode(code);
      setScanDone(true);
      try { navigator.vibrate?.(100); } catch(_) {}
      setTimeout(() => { setScanDone(false); setShowScan(false); setShowCamera(false); }, 1200);
    }
  };

  const isConforme = item.qty_contada === item.qty_factura && item.qty_factura > 0;

  return (
    <div style={{ borderBottom: isLast ? "none" : `1px solid ${C.separator}` }}>
      <div style={{ padding: "13px 16px", display: "flex", alignItems: "center", gap: 10, cursor: "pointer", background: active ? C.orangePale : C.white, transition: "background 0.15s" }}>
        <div style={{ width: 4, height: 36, borderRadius: 2, background: color, flexShrink: 0 }} onClick={onExpand} />
        <div style={{ flex: 1, minWidth: 0 }} onClick={onExpand}>
          <div style={{ fontSize: 15, fontWeight: 600, color: C.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{item.nombre}</div>
          <div style={{ fontSize: 12, color: C.textTertiary, marginTop: 1, display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
            <span style={{ color: C.orange, fontWeight: 500 }}>{item.referencia}</span>
            <span>· {item.unidad}</span>
            {item.codigoBarras && <span style={{ fontSize: 9, fontWeight: 600, color: C.blue, background: C.bluePale, padding: "1px 5px", borderRadius: 4, fontFamily: "monospace" }}>▮ {item.codigoBarras}</span>}
            {item.nota && <span style={{ fontSize: 9, color: C.amber }}>📝</span>}
            {confianza !== "alta" && <span style={{ fontSize: 9, fontWeight: 700, color: confColor, background: confColor + "18", padding: "1px 5px", borderRadius: 4, textTransform: "uppercase" }}>{confianza === "media" ? "REVISAR" : "BAJA CONF."}</span>}
          </div>
        </div>
        {/* POINT 7: Quick confirm button in row */}
        {!cerrada && !isConforme && (
          <button onClick={(e) => { e.stopPropagation(); onQuickConfirm(); }}
            style={{ background: C.green + "15", border: `1.5px solid ${C.green}40`, borderRadius: 8, padding: "6px 8px", color: C.green, fontSize: 10, fontWeight: 700, cursor: "pointer", fontFamily: SF, flexShrink: 0, whiteSpace: "nowrap" }}>
            ✓ {item.qty_factura}
          </button>
        )}
        {isConforme && <span style={{ fontSize: 16, flexShrink: 0 }}>✅</span>}
        <div style={{ display: "flex", alignItems: "center", gap: 6, flexShrink: 0 }} onClick={onExpand}>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: 10, color: C.textTertiary, fontWeight: 500 }}>FACT</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: C.textSecondary }}>{item.qty_factura}</div>
          </div>
          <div style={{ fontSize: 11, color: C.textTertiary }}>vs</div>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: 10, color, fontWeight: 600 }}>CONT</div>
            <div style={{ fontSize: 16, fontWeight: 700, color }}>{item.qty_contada}</div>
          </div>
          <div style={{ fontSize: 16, color: C.textTertiary, transform: active ? "rotate(180deg)" : "none", transition: "transform 0.2s" }}>⌄</div>
        </div>
      </div>

      {active && (
        <div style={{ background: "#FAFAFA", borderTop: `1px solid ${C.separator}`, padding: "16px" }}>
          {/* Quantity controls */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10 }}>
            <button onClick={() => onDelta(-5)} disabled={cerrada} style={ctrlBtn}>-5</button>
            <button onClick={() => onDelta(-1)} disabled={cerrada} style={ctrlBtn}>−</button>
            <input type="number" value={item.qty_contada} onChange={e => onSet(e.target.value)} disabled={cerrada}
              style={{ width: 80, height: 52, background: C.white, border: `2px solid ${color}`, borderRadius: 14, color, fontSize: 28, fontWeight: 700, textAlign: "center", fontFamily: SF, outline: "none" }} />
            <button onClick={() => onDelta(1)} disabled={cerrada} style={ctrlBtn}>+</button>
            <button onClick={() => onDelta(5)} disabled={cerrada} style={ctrlBtn}>+5</button>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <button onClick={() => onSet(item.qty_factura)} disabled={cerrada} style={{ flex: 1, background: color + "15", border: "none", borderRadius: 10, padding: "10px", color, fontFamily: SF, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
              = Conforme ({item.qty_factura})
            </button>
            <button onClick={onDelete} disabled={cerrada} style={{ background: C.redPale, border: "none", borderRadius: 10, padding: "10px 14px", color: C.red, fontFamily: SF, fontSize: 13, cursor: "pointer" }}>Eliminar</button>
          </div>

          {/* BARCODE */}
          {!showScan && !showCamera && (
            <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
              <button onClick={() => setShowCamera(true)}
                style={{ flex: 2, background: item.codigoBarras ? C.bluePale : "#E8F0FE", border: `2px dashed ${C.blue}`, borderRadius: 12, padding: "12px", color: C.blue, fontFamily: SF, fontSize: 13, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
                📷 {item.codigoBarras ? item.codigoBarras : "Escanear código"}
              </button>
              <button onClick={() => setShowScan(true)}
                style={{ flex: 1, background: C.white, border: `1.5px solid ${C.separator}`, borderRadius: 12, padding: "12px 8px", color: C.textSecondary, fontFamily: SF, fontSize: 11, fontWeight: 600, cursor: "pointer" }}>
                ⌨️ Manual
              </button>
            </div>
          )}
          {showCamera && <CameraScanner onScan={(code) => handleScan(code)} onClose={() => setShowCamera(false)} />}
          {showScan && (
            <div style={{ marginTop: 12, background: C.white, border: `2px solid ${scanDone ? C.green : C.blue}`, borderRadius: 12, padding: 12, animation: "fadeIn 0.15s ease" }}>
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <input ref={scanRef} type="text" autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck="false"
                  defaultValue={item.codigoBarras || ""}
                  onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); handleScan(e.target.value); } }}
                  placeholder="Escribe o pistola..."
                  style={{ flex: 1, background: "#F8FAFF", border: `2px solid ${scanDone ? C.green : C.blue + "40"}`, borderRadius: 10, padding: "12px", fontFamily: "'SF Mono', monospace", fontSize: 16, color: C.text, outline: "none" }} />
                <button onClick={() => { if (scanRef.current?.value?.trim()) handleScan(scanRef.current.value); }}
                  style={{ background: C.blue, border: "none", borderRadius: 10, padding: "12px 14px", color: "#fff", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: SF }}>{scanDone ? "✓" : "OK"}</button>
                <button onClick={() => setShowScan(false)} style={{ background: C.bg, border: "none", borderRadius: 10, padding: "12px", color: C.textTertiary, fontSize: 12, cursor: "pointer" }}>✕</button>
              </div>
              {item.codigoBarras && <div style={{ fontSize: 11, color: C.green, fontWeight: 600, marginTop: 6, display: "flex", justifyContent: "space-between" }}><span>✓ {item.codigoBarras}</span><button onClick={() => onBarcode("")} style={{ fontSize: 11, color: C.red, background: "none", border: "none", cursor: "pointer", fontFamily: SF }}>Borrar</button></div>}
            </div>
          )}

          {/* POINT 11: Notes */}
          {!editNota && (
            <button onClick={() => setEditNota(true)}
              style={{ width: "100%", marginTop: 10, background: item.nota ? C.amberPale : C.white, border: `1px solid ${item.nota ? C.amber + "40" : C.separator}`, borderRadius: 10, padding: "10px 12px", color: item.nota ? C.text : C.textTertiary, fontFamily: SF, fontSize: 12, cursor: "pointer", textAlign: "left" }}>
              {item.nota ? `📝 ${item.nota}` : "📝 Agregar nota..."}
            </button>
          )}
          {editNota && (
            <div style={{ marginTop: 10, display: "flex", gap: 8, alignItems: "flex-start" }}>
              <textarea ref={notaRef} defaultValue={item.nota || ""} placeholder="Caja dañada, color incorrecto, verificar..."
                style={{ flex: 1, background: C.white, border: `1.5px solid ${C.amber}`, borderRadius: 10, padding: "10px", fontFamily: SF, fontSize: 13, color: C.text, outline: "none", resize: "vertical", minHeight: 50 }}
                onBlur={e => { onNota(e.target.value.trim()); setEditNota(false); }}
                onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); onNota(e.target.value.trim()); setEditNota(false); } }}
              />
              <button onClick={() => { if (notaRef.current) { onNota(notaRef.current.value.trim()); } setEditNota(false); }}
                style={{ background: C.amber, border: "none", borderRadius: 8, padding: "10px 12px", color: "#fff", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: SF }}>OK</button>
            </div>
          )}

          {cerrada && item.codigoBarras && !showScan && (
            <div style={{ marginTop: 10, fontSize: 14, color: C.blue, fontFamily: "monospace", background: C.bluePale, borderRadius: 8, padding: "10px 12px", fontWeight: 600 }}>▮ {item.codigoBarras}</div>
          )}
        </div>
      )}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   RESUMEN
══════════════════════════════════════════════════════════ */
function ResumenView({ rec }) {
  const totalFact = rec.items.reduce((s, it) => s + it.qty_factura, 0);
  const totalCont = rec.items.reduce((s, it) => s + it.qty_contada, 0);
  const ok = totalFact > 0 && totalCont === totalFact;
  const grupos = [
    { label: "Conformes", color: C.green, bg: C.greenPale, items: rec.items.filter(it => it.qty_contada === it.qty_factura && it.qty_factura > 0) },
    { label: "Faltantes", color: C.amber, bg: C.amberPale, items: rec.items.filter(it => it.qty_contada < it.qty_factura && it.qty_contada > 0) },
    { label: "Exceso", color: C.blue, bg: C.bluePale, items: rec.items.filter(it => it.qty_contada > it.qty_factura) },
    { label: "Sin contar", color: C.red, bg: C.redPale, items: rec.items.filter(it => it.qty_contada === 0 && it.qty_factura > 0) },
  ].filter(g => g.items.length > 0);

  // Count low confidence items
  const lowConf = rec.items.filter(it => it.confianza === "baja" || it.confianza === "media");

  return (
    <div>
      <div style={{ background: C.white, borderRadius: 16, padding: "20px", marginBottom: 16, boxShadow: "0 1px 3px rgba(0,0,0,0.06)", border: `2px solid ${ok ? C.green + "40" : C.separator}` }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0 }}>
          <div style={{ textAlign: "center", borderRight: `1px solid ${C.separator}`, padding: "8px 0" }}>
            <div style={{ fontSize: 12, color: C.textTertiary, fontWeight: 500, marginBottom: 4 }}>TOTAL FACTURA</div>
            <div style={{ fontSize: 40, fontWeight: 700, color: C.textSecondary }}>{totalFact}</div>
          </div>
          <div style={{ textAlign: "center", padding: "8px 0" }}>
            <div style={{ fontSize: 12, color: ok ? C.green : C.amber, fontWeight: 600, marginBottom: 4 }}>TOTAL CONTADO</div>
            <div style={{ fontSize: 40, fontWeight: 700, color: ok ? C.green : C.amber }}>{totalCont}</div>
          </div>
        </div>
        {rec.proveedor && <div style={{ marginTop: 12, padding: "10px 14px", background: C.orangePale, borderRadius: 10, fontSize: 13, color: C.text }}><span style={{ color: C.orange, fontWeight: 600 }}>Proveedor: </span>{rec.proveedor}{rec.nro_factura ? ` · ${rec.nro_factura}` : ""}</div>}
      </div>

      {/* Low confidence warning */}
      {lowConf.length > 0 && (
        <div style={{ background: C.amberPale, borderRadius: 14, padding: "12px 16px", marginBottom: 14, border: `1px solid ${C.amber}30` }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: C.amber, marginBottom: 4 }}>⚠️ {lowConf.length} producto{lowConf.length > 1 ? "s" : ""} con lectura incierta</div>
          <div style={{ fontSize: 12, color: C.textSecondary }}>Verifica manualmente los códigos marcados como "REVISAR" o "BAJA CONF."</div>
          <div style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 4 }}>
            {lowConf.map(it => (
              <div key={it.id} style={{ fontSize: 12, color: C.text }}>
                <span style={{ color: C.orange, fontWeight: 600 }}>{it.referencia}</span> — {it.nombre}
                <span style={{ fontSize: 10, color: it.confianza === "baja" ? C.red : C.amber, fontWeight: 700, marginLeft: 6 }}>({it.confianza})</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {grupos.map(g => (
        <div key={g.label} style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: g.color, letterSpacing: 0.5, marginBottom: 8, paddingLeft: 4, textTransform: "uppercase" }}>{g.label} ({g.items.length})</div>
          <div style={{ background: C.white, borderRadius: 14, overflow: "hidden", boxShadow: "0 1px 3px rgba(0,0,0,0.05)" }}>
            {g.items.map((it, i) => (
              <div key={it.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "11px 16px", borderBottom: i === g.items.length - 1 ? "none" : `1px solid ${C.separator}` }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <span style={{ fontSize: 14, fontWeight: 500, color: C.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", display: "block" }}>{it.nombre}</span>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                    <span style={{ fontSize: 11, color: C.orange }}>{it.referencia}</span>
                    {it.codigoBarras && <span style={{ fontSize: 9, color: C.blue, fontFamily: "monospace", background: C.bluePale, padding: "1px 4px", borderRadius: 3 }}>▮ {it.codigoBarras}</span>}
                    {it.nota && <span style={{ fontSize: 9, color: C.amber }}>📝 {it.nota}</span>}
                  </div>
                </div>
                <div style={{ fontSize: 14, fontWeight: 700, color: C.textSecondary, marginLeft: 12, whiteSpace: "nowrap" }}>
                  {it.qty_factura} → <span style={{ color: g.color }}>{it.qty_contada}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* POINT 9: WhatsApp message for differences */}
      {(() => {
        const diffs = rec.items.filter(it => it.qty_contada !== it.qty_factura && it.qty_factura > 0);
        if (diffs.length === 0) return null;
        const msg = `*REPORTE DE DIFERENCIAS*\n${rec.proveedor ? `Proveedor: ${rec.proveedor}\n` : ""}${rec.nro_factura ? `Factura: ${rec.nro_factura}\n` : ""}${rec.nombre}\n\n` +
          diffs.map(it => {
            const diff = it.qty_contada - it.qty_factura;
            const label = it.qty_contada === 0 ? "NO LLEGÓ" : diff < 0 ? `FALTAN ${Math.abs(diff)}` : `EXCESO +${diff}`;
            return `• ${it.referencia} — ${it.nombre}\n  Factura: ${it.qty_factura} | Recibido: ${it.qty_contada} | ${label}${it.nota ? `\n  Nota: ${it.nota}` : ""}`;
          }).join("\n\n") +
          `\n\n_Total diferencias: ${diffs.length} productos_`;
        const url = `https://wa.me/?text=${encodeURIComponent(msg)}`;
        return (
          <button onClick={() => window.open(url, "_blank")}
            style={{ width: "100%", marginTop: 16, background: "#25D366", border: "none", borderRadius: 14, padding: "14px", color: "#fff", fontFamily: SF, fontSize: 15, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, boxShadow: "0 4px 14px rgba(37,211,102,0.3)" }}>
            💬 Enviar diferencias por WhatsApp ({diffs.length})
          </button>
        );
      })()}

      {/* EXPORT PDF BUTTON */}
      <button onClick={() => exportPDF(rec)} style={{ width: "100%", marginTop: 10, background: C.orange, border: "none", borderRadius: 14, padding: "14px", color: "#fff", fontFamily: SF, fontSize: 15, fontWeight: 700, cursor: "pointer", boxShadow: `0 4px 14px ${C.orange}44`, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
        📄 Exportar PDF
      </button>
    </div>
  );
}

/* ─── PDF EXPORT ───────────────────────────────────────── */
function exportPDF(rec) {
  const totalFact = rec.items.reduce((s, it) => s + it.qty_factura, 0);
  const totalCont = rec.items.reduce((s, it) => s + it.qty_contada, 0);
  const conformes = rec.items.filter(it => it.qty_contada === it.qty_factura && it.qty_factura > 0).length;
  const faltantes = rec.items.filter(it => it.qty_contada < it.qty_factura && it.qty_contada > 0).length;
  const sinContar = rec.items.filter(it => it.qty_contada === 0 && it.qty_factura > 0).length;
  const exceso = rec.items.filter(it => it.qty_contada > it.qty_factura).length;
  const fecha = new Date().toLocaleDateString("es-VE", { day: "2-digit", month: "long", year: "numeric" });
  const hora = new Date().toLocaleTimeString("es-VE", { hour: "2-digit", minute: "2-digit" });

  const statusOf = (it) => {
    if (it.qty_contada === 0 && it.qty_factura > 0) return { label: "SIN CONTAR", color: "#FF3B30" };
    if (it.qty_contada === it.qty_factura) return { label: "CONFORME", color: "#34C759" };
    if (it.qty_contada < it.qty_factura) return { label: `FALTAN ${it.qty_factura - it.qty_contada}`, color: "#FF9500" };
    return { label: `EXCESO +${it.qty_contada - it.qty_factura}`, color: "#007AFF" };
  };

  // Build table rows
  const tableRows = rec.items.map((it, i) => {
    const st = statusOf(it);
    return `<tr style="border-bottom:1px solid #E8E8E8;${i % 2 === 0 ? "" : "background:#FAFAFA;"}">
      <td style="padding:8px 10px;font-size:11px;color:#888;text-align:center;">${it.item || i+1}</td>
      <td style="padding:8px 10px;font-size:11px;font-family:monospace;color:#FF6B00;font-weight:600;">${it.referencia}</td>
      <td style="padding:8px 10px;font-size:11px;color:#1C1C1E;max-width:200px;">${it.nombre}${it.nota ? `<div style="font-size:9px;color:#FF9500;margin-top:2px;">📝 ${it.nota}</div>` : ""}</td>
      <td style="padding:8px 10px;font-size:11px;text-align:center;color:#6C6C70;">${it.unidad}</td>
      <td style="padding:8px 10px;font-size:12px;text-align:center;font-weight:700;color:#6C6C70;">${it.qty_factura}</td>
      <td style="padding:8px 10px;font-size:12px;text-align:center;font-weight:700;color:${st.color};">${it.qty_contada}</td>
      <td style="padding:8px 10px;font-size:10px;font-family:monospace;color:#888;text-align:center;">${it.codigoBarras || "—"}</td>
      <td style="padding:8px 10px;text-align:center;"><span style="font-size:9px;font-weight:700;color:${st.color};background:${st.color}15;padding:2px 6px;border-radius:4px;">${st.label}</span></td>
    </tr>`;
  }).join("");

  const html = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>${rec.nombre}</title>
<style>
  @page { size: A4 landscape; margin: 15mm; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, 'Segoe UI', sans-serif; color: #1C1C1E; background: #fff; }
  @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
</style></head>
<body style="padding:20px;">

  <!-- Header -->
  <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px;padding-bottom:16px;border-bottom:3px solid #FF6B00;">
    <div>
      <div style="font-size:24px;font-weight:800;color:#1C1C1E;letter-spacing:-0.5px;">${rec.nombre}</div>
      <div style="font-size:13px;color:#6C6C70;margin-top:4px;">${fecha} · ${hora}</div>
      ${rec.proveedor ? `<div style="font-size:14px;color:#FF6B00;font-weight:600;margin-top:6px;">${rec.proveedor}${rec.nro_factura ? " · " + rec.nro_factura : ""}</div>` : ""}
    </div>
    <div style="text-align:right;">
      <div style="font-size:11px;color:#AEAEB2;font-weight:500;">RECEPCION DE MERCANCIA</div>
      <div style="font-size:11px;color:#AEAEB2;margin-top:2px;">${rec.items.length} productos · ${rec.facturas_procesadas || 0} facturas</div>
    </div>
  </div>

  <!-- Stats -->
  <div style="display:flex;gap:12px;margin-bottom:20px;">
    <div style="flex:1;background:#E8F8ED;border-radius:10px;padding:12px;text-align:center;">
      <div style="font-size:28px;font-weight:800;color:#34C759;">${conformes}</div>
      <div style="font-size:10px;color:#34C759;font-weight:600;">CONFORMES</div>
    </div>
    <div style="flex:1;background:#FFF4E0;border-radius:10px;padding:12px;text-align:center;">
      <div style="font-size:28px;font-weight:800;color:#FF9500;">${faltantes}</div>
      <div style="font-size:10px;color:#FF9500;font-weight:600;">FALTANTES</div>
    </div>
    <div style="flex:1;background:#FFEBEA;border-radius:10px;padding:12px;text-align:center;">
      <div style="font-size:28px;font-weight:800;color:#FF3B30;">${sinContar}</div>
      <div style="font-size:10px;color:#FF3B30;font-weight:600;">SIN CONTAR</div>
    </div>
    <div style="flex:1;background:#EBF4FF;border-radius:10px;padding:12px;text-align:center;">
      <div style="font-size:28px;font-weight:800;color:#007AFF;">${exceso}</div>
      <div style="font-size:10px;color:#007AFF;font-weight:600;">EXCESO</div>
    </div>
    <div style="flex:1;background:#F2F2F7;border-radius:10px;padding:12px;text-align:center;">
      <div style="font-size:22px;font-weight:800;color:#6C6C70;">${totalCont}<span style="font-size:14px;color:#AEAEB2;">/${totalFact}</span></div>
      <div style="font-size:10px;color:#6C6C70;font-weight:600;">TOTAL</div>
    </div>
  </div>

  <!-- Table -->
  <table style="width:100%;border-collapse:collapse;border:1px solid #E5E5EA;border-radius:8px;overflow:hidden;">
    <thead>
      <tr style="background:#1C1C1E;">
        <th style="padding:10px;font-size:10px;color:#fff;font-weight:600;text-align:center;letter-spacing:0.5px;">#</th>
        <th style="padding:10px;font-size:10px;color:#fff;font-weight:600;text-align:left;letter-spacing:0.5px;">REF</th>
        <th style="padding:10px;font-size:10px;color:#fff;font-weight:600;text-align:left;letter-spacing:0.5px;">PRODUCTO</th>
        <th style="padding:10px;font-size:10px;color:#fff;font-weight:600;text-align:center;letter-spacing:0.5px;">UND</th>
        <th style="padding:10px;font-size:10px;color:#fff;font-weight:600;text-align:center;letter-spacing:0.5px;">FACT</th>
        <th style="padding:10px;font-size:10px;color:#fff;font-weight:600;text-align:center;letter-spacing:0.5px;">CONT</th>
        <th style="padding:10px;font-size:10px;color:#fff;font-weight:600;text-align:center;letter-spacing:0.5px;">COD. BARRAS</th>
        <th style="padding:10px;font-size:10px;color:#fff;font-weight:600;text-align:center;letter-spacing:0.5px;">ESTADO</th>
      </tr>
    </thead>
    <tbody>${tableRows}</tbody>
    <tfoot>
      <tr style="background:#F2F2F7;border-top:2px solid #1C1C1E;">
        <td colspan="4" style="padding:10px;font-size:12px;font-weight:700;text-align:right;">TOTALES</td>
        <td style="padding:10px;font-size:14px;font-weight:800;text-align:center;">${totalFact}</td>
        <td style="padding:10px;font-size:14px;font-weight:800;text-align:center;color:${totalCont === totalFact ? "#34C759" : "#FF9500"};">${totalCont}</td>
        <td colspan="2"></td>
      </tr>
    </tfoot>
  </table>

  <!-- Footer -->
  <div style="margin-top:20px;padding-top:12px;border-top:1px solid #E5E5EA;display:flex;justify-content:space-between;">
    <div style="font-size:10px;color:#AEAEB2;">Generado automaticamente · Sistema de Recepcion de Almacen</div>
    <div style="font-size:10px;color:#AEAEB2;">Firma: ________________________</div>
  </div>

</body></html>`;

  const blob = new Blob([html], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${rec.nombre.replace(/[^a-zA-Z0-9]/g, "-")}-${new Date().toISOString().slice(0,10)}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  // User opens the downloaded .html in Chrome → Share → Print → Save as PDF
}

/* ══════════════════════════════════════════════════════════
   MICRO COMPONENTS
══════════════════════════════════════════════════════════ */
function MiniStat({ color, bg, label, value }) {
  return <div style={{ background: bg, borderRadius: 14, padding: "12px 10px", textAlign: "center" }}>
    <div style={{ fontSize: 26, fontWeight: 700, color, lineHeight: 1 }}>{value}</div>
    <div style={{ fontSize: 11, color, opacity: 0.7, fontWeight: 500, marginTop: 3 }}>{label}</div>
  </div>;
}
function MetaField({ label, value, onChange, placeholder }) {
  const [editing, setEditing] = useState(false);
  const [v, setV] = useState(value || "");
  const commit = () => { if (onChange) onChange(v); setEditing(false); };
  return (
    <div onClick={() => onChange && setEditing(true)} style={{ cursor: onChange ? "text" : "default" }}>
      <div style={{ fontSize: 11, color: C.textTertiary, fontWeight: 500, marginBottom: 2 }}>{label}</div>
      {editing
        ? <input autoFocus value={v} onChange={e => setV(e.target.value)} onBlur={commit} onKeyDown={e => e.key === "Enter" && commit()} placeholder={placeholder} style={{ background: "none", border: "none", borderBottom: `1.5px solid ${C.orange}`, color: C.text, fontSize: 14, fontFamily: SF, fontWeight: 500, outline: "none", width: 130 }} />
        : <div style={{ fontSize: 14, color: v ? C.text : C.textTertiary, fontWeight: 500 }}>{v || placeholder}</div>
      }
    </div>
  );
}
function Loader() {
  return (
    <div style={{ background: C.bg, height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: SF }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ width: 60, height: 60, background: C.orangePale, borderRadius: 18, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, margin: "0 auto 14px" }}>📋</div>
        <div style={{ fontSize: 16, fontWeight: 600, color: C.text }}>Cargando...</div>
      </div>
    </div>
  );
}
